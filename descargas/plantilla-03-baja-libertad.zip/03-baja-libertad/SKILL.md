---
name: TODO-en-gerundio
description: TODO qué hace + cuándo usarla.
allowed-tools: Bash Read
disable-model-invocation: true
---

> Esta skill tiene efectos irreversibles. Solo se invoca manualmente.
> No se activa sola.

## Procedimiento

Ejecuta **exactamente** estos pasos, en este orden. No agregues
banderas, no combines pasos, no optimices.

### 1. Verificación previa

    bash ${CLAUDE_SKILL_DIR}/scripts/verificar-estado.sh

Si reporta algo distinto de `ESTADO: LIMPIO`, **detente** y reporta.

### 2. TODO: el comando exacto

    TODO

No modifiques este comando aunque el error sugiera hacerlo.

### 3. Si falla

Detente. Reporta el error completo. No intentes corregirlo.

<!-- Grado de libertad: BAJA. Puente angosto con precipicios. -->
