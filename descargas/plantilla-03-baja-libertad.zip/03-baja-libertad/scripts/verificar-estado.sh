#!/usr/bin/env bash
set -uo pipefail
problemas=0

# TODO: agrega tus verificaciones
# if [ condición ]; then echo "PROBLEMA: ..."; problemas=$((problemas+1)); fi

if [ "$problemas" -eq 0 ]; then
  echo "ESTADO: LIMPIO"
else
  echo "ESTADO: $problemas problema(s). No continuar."
fi
