---
name: TODO-en-gerundio
description: TODO qué hace, en tercera persona, empezando por el caso
  principal. Úsala cuando el usuario TODO — pon aquí las palabras que
  escribirías tú de verdad al pedirlo.
---

## Instrucciones

TODO: el procedimiento, en imperativo, dirigido a Claude.

Solo escribe lo que Claude NO sabe ya. Si estás explicando qué es un
pull request o cómo funciona git, bórralo.

<!-- Grado de libertad: TODO alta / media / baja -->
