---
name: TODO-en-gerundio
description: TODO qué hace + cuándo usarla, en tercera persona.
allowed-tools: Read Grep Bash
---

## Instrucciones

1. Ejecuta la verificación:

       bash ${CLAUDE_SKILL_DIR}/scripts/verificar.sh

2. TODO: qué hacer con el resultado.

3. Para el detalle de los casos especiales, consulta
   ${CLAUDE_SKILL_DIR}/reference.md

<!--
  REGLAS DE ESTRUCTURA
  · reference.md NO puede referenciar a un tercer archivo (un solo nivel)
  · los scripts se EJECUTAN, no se leen
  · rutas siempre con ${CLAUDE_SKILL_DIR}
  · este archivo por debajo de 500 líneas
-->
