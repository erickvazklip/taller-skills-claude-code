#!/usr/bin/env bash
# TODO: qué verifica este script.
# Debe imprimir un resultado legible y salir con 0 aunque encuentre
# problemas: quien decide qué hacer con ellos es Claude, no el script.
set -uo pipefail

echo "RESULTADO: TODO"
