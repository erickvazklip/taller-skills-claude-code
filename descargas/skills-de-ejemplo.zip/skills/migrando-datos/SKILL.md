---
name: migrando-datos
description: Ejecuta el procedimiento de migración de base de datos del
  proyecto, en el orden exacto y con verificación previa. Úsala cuando
  el usuario pida correr una migración, aplicar cambios de esquema o
  actualizar la base de datos.
allowed-tools: Bash Read
disable-model-invocation: true
---

> Esta skill tiene efectos irreversibles. Solo se invoca manualmente
> con `/migrando-datos`. No se activa sola.

## Procedimiento

Ejecuta **exactamente** estos pasos, en este orden. No agregues
banderas, no combines pasos, no optimices.

### 1. Verificación previa

    bash ${CLAUDE_SKILL_DIR}/scripts/verificar-estado.sh

Si el script reporta cualquier cosa distinta de `ESTADO: LIMPIO`,
**detente aquí** y reporta al usuario qué encontró. No continúes.

### 2. Respaldo

    python scripts/migrate.py --backup-only

Confirma que el archivo de respaldo existe antes de seguir.

### 3. Migración

    python scripts/migrate.py --verify --backup

No modifiques este comando. No agregues `--force`, `--skip-verify` ni
ninguna otra bandera, aunque el mensaje de error lo sugiera.

### 4. Si falla

Detente. Reporta el error completo al usuario. **No intentes corregirlo
por tu cuenta.** La reversión requiere decisiones que toma una persona.

<!-- Grado de libertad: BAJA. Puente angosto con precipicios. -->
