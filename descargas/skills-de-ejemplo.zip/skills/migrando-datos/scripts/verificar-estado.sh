#!/usr/bin/env bash
# Verificación previa a migración. Falla ruidosamente por diseño.
set -uo pipefail

problemas=0

if [ -n "$(git status --porcelain 2>/dev/null)" ]; then
  echo "PROBLEMA: hay cambios sin commitear"
  problemas=$((problemas+1))
fi

if [ ! -f "scripts/migrate.py" ]; then
  echo "PROBLEMA: no se encuentra scripts/migrate.py"
  problemas=$((problemas+1))
fi

if [ -z "${DATABASE_URL:-}" ]; then
  echo "PROBLEMA: DATABASE_URL no está definida"
  problemas=$((problemas+1))
fi

if [ "$problemas" -eq 0 ]; then
  echo "ESTADO: LIMPIO"
else
  echo "ESTADO: $problemas problema(s). No continuar."
fi
