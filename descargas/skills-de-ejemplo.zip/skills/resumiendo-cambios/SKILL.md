---
name: resumiendo-cambios
description: Resume los cambios sin commitear y señala lo riesgoso.
  Úsala cuando el usuario pregunte qué cambió, pida un mensaje de
  commit, quiera revisar su diff o pregunte si su trabajo está listo
  para subir.
allowed-tools: Read Grep
---

## Cambios actuales

!`git diff HEAD`

## Archivos tocados

!`git status --short`

## Instrucciones

Resume en dos o tres viñetas qué cambió, en términos de intención y no
de líneas. "Se agregó validación al formulario de registro", no "se
modificaron 14 líneas en form.js".

Después lista los riesgos que encuentres. Busca específicamente:

- Manejo de errores ausente en operaciones que pueden fallar
- Valores hardcodeados que deberían ser configuración
- Pruebas que quedaron desactualizadas respecto al código que tocaste
- Cambios en interfaces públicas sin actualizar a quien las consume

Si no encuentras riesgos, dilo en una línea. No inventes hallazgos
para llenar la sección.

<!-- Grado de libertad: ALTA. Varios enfoques de resumen son válidos. -->
