# Qué debe contener cada sección

## Título y descripción de una línea
Qué es el proyecto y para qué sirve, en una frase que entienda alguien
que llegó por accidente. Sin jerga interna.

## Requisitos
Versiones mínimas de runtime, dependencias de sistema, variables de
entorno obligatorias. Con números de versión, no "reciente".

## Instalación
Comandos exactos, copiables, en orden. Si hay pasos distintos por
sistema operativo, se separan.

## Uso
Al menos un ejemplo completo que funcione al copiarlo. No fragmentos
que asuman contexto previo.

## Configuración
Tabla de variables: nombre, para qué sirve, valor por defecto, si es
obligatoria.

## Desarrollo
Cómo levantar el entorno local, cómo correr las pruebas, cómo contribuir.

## Licencia
Nombre de la licencia y enlace al archivo.

---

# Señales de un README incompleto

- Instalación sin comandos copiables
- Ejemplos que asumen configuración no documentada
- Variables de entorno mencionadas en el código pero no aquí
- Enlaces rotos a documentación interna
- Instrucciones que solo funcionan en la máquina de quien lo escribió
