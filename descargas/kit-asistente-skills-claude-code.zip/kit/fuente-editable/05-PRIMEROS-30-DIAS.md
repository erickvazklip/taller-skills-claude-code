# Tus primeros 30 días
### Guía de adopción, para que esto no se quede en el webinar

La mayoría de quienes ven un webinar no aplican nada. No es falta de
interés: es que no hay un siguiente paso concreto. Esta guía es el
siguiente paso.

---

## Día 1 · Hoy, 20 minutos

### 1 · Instala una skill del kit (5 min)

No escribas nada todavía. Copia una del kit y úsala:

```bash
cp -r kit-skills/desarrollo/redactando-commits ~/.claude/skills/
```

Haz cualquier cambio en un repositorio, prepáralo con `git add`, y pide:

```
dame un mensaje de commit para esto
```

**Fíjate en que no escribiste `/`.** Se disparó sola porque la descripción
coincidió. Ese es todo el mecanismo.

### 2 · Mira qué tienes (2 min)

```
/skills
```

Reconoce cuál viene de dónde. Es el mapa mental que necesitas.

### 3 · Anota tu caso (3 min)

Responde por escrito, en una línea:

> ¿Qué le pido a Claude cada semana, escribiendo más o menos lo mismo?

No sigas hasta tener la respuesta. Es el insumo de todo lo demás.

### 4 · Construye tu primera skill (10 min)

Resuelve ese caso con prompting normal. Cuando el resultado te sirva,
pega el **prompt destilador** (archivo 03).

Crea la carpeta, abre sesión nueva, y pide la tarea en lenguaje natural.

---

## Semana 1 · Úsala, no la mejores

**Tres usos reales mínimo.** No la toques todavía.

Lleva una nota de una línea cada vez que tropiece:

```
lun · se disparó bien, pero ignoró las pruebas
mié · no se disparó cuando escribí "revisa esto antes de subirlo"
vie · bien
```

Esas dos líneas son tu lista de correcciones, y son mejores que cualquier
mejora que se te ocurra en abstracto.

**Por qué no mejorarla antes:** una skill que no se usa no se puede
mejorar. Sin datos de uso, las "mejoras" son suposiciones.

---

## Semana 2 · Una corrección y una skill más

### Corrige con el ciclo

Vuelve a la conversación donde la construiste:

```
No se disparó cuando escribí "revisa esto antes de subirlo".
Reescribe solo la descripción para que esa frase la active.
```

Prueba en sesión nueva. Una corrección por vez.

### Construye la segunda

La segunda sale en la mitad de tiempo. Elige un caso de otra categoría:
si la primera fue de código, que esta sea de documento o de proyecto.

---

## Semana 3 · Llévala al equipo

### Elige la que más usaste

Mira tus notas. La que más aparece es la candidata.

### Límpiala

Usa la **variante para equipo** del prompt destilador (archivo 03). Quita
rutas de tu máquina, datos reales, supuestos que solo tú conoces.

### Súbela

```bash
mkdir -p .claude/skills
cp -r ~/.claude/skills/tu-skill .claude/skills/
git add .claude/skills && git commit -m "add: skill tu-skill"
```

### Pide una prueba real

A alguien del equipo:

> Clona el repo y pídele a Claude que haga X. No te explico nada más.

**Si necesita explicación, la descripción no fue suficiente.** Ese es el
dato que buscas, y es más valioso que un "sí, está bien".

---

## Semana 4 · Mide y decide

### Tres preguntas

1. ¿Cuántas skills tienes en uso real, no escritas?
2. ¿Cuál no has invocado en dos semanas?
3. ¿Alguien más del equipo usa alguna?

### Qué hacer con cada respuesta

| Situación | Acción |
|---|---|
| Tienes 1 en uso | Suficiente. Es más de lo que tiene la mayoría |
| Tienes 3 o más | Revisa si alguna se solapa con otra |
| Una no se usó en 2 semanas | Bórrala. Una skill que miente es peor que ninguna |
| Nadie más las usa | Pregunta por qué. Suele ser que no saben que existen |

### Si llegaste hasta aquí

Instala la skill `auditando-skills` del kit y córrela sobre tus propias
skills. Te va a encontrar cosas que no ves porque las escribiste tú.

---

## Los tres errores que hacen que esto se abandone

**1 · Empezar por la skill perfecta.**
La primera skill debe ser fea y útil. La perfecta nunca se termina.

**2 · Escribir cinco de golpe.**
Sin uso real no sabes cuál sirve. Una, usada tres veces, enseña más que
cinco sin estrenar.

**3 · Mejorarla sin usarla.**
Es la trampa más común. Las mejoras que se te ocurren en abstracto casi
nunca son las que el uso revela.

---

## Cuando te atores

| Problema | Dónde buscar |
|---|---|
| No se activa | Manual §7 y §21, o la tarjeta |
| No sé qué poner en el cuerpo | Prompt destilador, archivo 03 |
| No sé si esto va en skill o en CLAUDE.md | Manual §23 |
| Quiero ver un ejemplo real | Kit de skills, carpeta por categoría |
| Mi skill funciona pero está desordenada | Manual §10, partir una skill |
