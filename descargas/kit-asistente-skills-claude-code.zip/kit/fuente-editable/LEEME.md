# Fuentes editables

Estos son los archivos markdown de los que se generaron los PDF de la
carpeta `PDF/`. Se incluyen por si quieres adaptar el material: cambiar un
ejemplo, agregar una política de tu organización, traducirlo.

| Archivo | Genera |
|---|---|
| `01-MANUAL.md` | `PDF/01-Manual-Skills-Claude-Code.pdf` |
| `02-TARJETA-REFERENCIA.md` | `PDF/02-Tarjeta-de-referencia.pdf` |
| `05-PRIMEROS-30-DIAS.md` | `PDF/03-Primeros-30-dias.pdf` |

**Para leer, usa los PDF.** Estos archivos son para editar.
