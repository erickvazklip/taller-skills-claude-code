#!/usr/bin/env bash
# TODO: qué verifica este script.
#
# Reglas del buen script de skill:
#  · sale con 0 aunque encuentre problemas; quien decide es Claude
#  · imprime resultados legibles y estructurados, no volcados crudos
#  · no depende de rutas absolutas de tu máquina
set -uo pipefail

echo "RESULTADO: TODO"
