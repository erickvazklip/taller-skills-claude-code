# Detalle de referencia

Esto se carga SOLO cuando Claude decide que le hace falta. Aquí va lo
voluminoso: tablas, casos especiales, catálogos, especificaciones.

## TODO: sección

TODO: contenido

<!-- No referencies otros archivos desde aquí. Un solo nivel. -->
