---
description: TODO qué hace, en tercera persona, empezando por el caso
  principal. Úsala cuando el usuario TODO — pon aquí las palabras que
  escribirías tú de verdad al pedirlo, no lenguaje de manual.
---

## Instrucciones

TODO: el procedimiento, en imperativo, dirigido a Claude.

Solo escribe lo que Claude NO sabe ya. Si estás explicando qué es un
pull request o cómo funciona git, bórralo.

Recuerda: este contenido se queda en contexto turno tras turno. Cada
línea es costo recurrente. Enuncia qué hacer, no narres por qué.

<!-- Grado de libertad: TODO ALTA / MEDIA / BAJA -->
