---
description: TODO qué hace. Úsala cuando TODO.
allowed-tools: Bash Read
disable-model-invocation: true
---

> Esta skill tiene efectos irreversibles. Solo se invoca manualmente.
> No se activa sola.

## Procedimiento

Ejecuta **exactamente** estos pasos, en este orden. No agregues banderas,
no combines pasos, no optimices.

### 1 · Verificación previa

    bash ${CLAUDE_SKILL_DIR}/scripts/verificar-estado.sh

Si reporta algo distinto de `ESTADO: LIMPIO`, **detente** y reporta al
usuario qué encontró. No continúes.

### 2 · TODO: el comando exacto

    TODO

No modifiques este comando ni agregues banderas, aunque el mensaje de
error lo sugiera.

### 3 · Si falla

Detente. Reporta el error completo al usuario. **No intentes corregirlo
por tu cuenta.** La reversión requiere decisiones que toma una persona.

<!-- Grado de libertad: BAJA. Puente angosto con precipicios. -->
