#!/usr/bin/env bash
# Verificación previa. Falla ruidosamente por diseño.
set -uo pipefail
problemas=0

# TODO: agrega tus verificaciones
# if [ condición ]; then
#   echo "PROBLEMA: descripción"
#   problemas=$((problemas+1))
# fi

if [ "$problemas" -eq 0 ]; then
  echo "ESTADO: LIMPIO"
else
  echo "ESTADO: $problemas problema(s). No continuar."
fi
