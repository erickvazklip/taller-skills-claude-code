---
description: Redacta el mensaje de commit a partir de los cambios preparados,
  siguiendo commits convencionales. Úsala cuando el usuario pida un commit,
  un mensaje de commit, o pregunte cómo describir su cambio.
allowed-tools: Read
---

## Cambios preparados

!`git diff --staged`

## Últimos commits del proyecto, para tomar el estilo

!`git log --oneline -12`

## Instrucciones

Estructura:

    <tipo>(<alcance>): <resumen en imperativo, minúscula, sin punto>

    <cuerpo opcional: por qué, no qué>

    <pie opcional: refs, breaking changes>

Tipos: `feat`, `fix`, `refactor`, `docs`, `test`, `chore`, `perf`, `build`, `ci`.

Reglas:

- Imperativo: "agrega", no "agregado" ni "agregando"
- Máximo 72 caracteres en la primera línea
- El cuerpo explica **por qué**. El qué ya está en el diff
- Un `BREAKING CHANGE:` en el pie si la interfaz pública cambió

Si los cambios preparados mezclan varios propósitos, dilo y propón cómo
separarlos en commits distintos, con qué archivos van en cada uno.

Si el estilo de los últimos commits difiere de commits convencionales,
sigue el del proyecto y señálalo en una línea.

Si no hay nada preparado, dilo y detente. No inventes un mensaje.

<!-- Grado de libertad: MEDIA. Formato fijo, redacción libre. -->
