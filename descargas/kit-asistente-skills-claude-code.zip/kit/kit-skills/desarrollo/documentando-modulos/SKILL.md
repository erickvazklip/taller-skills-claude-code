---
description: Documenta un módulo o componente explicando qué resuelve y cómo
  se usa, no qué hace línea por línea. Úsala cuando el usuario pida
  documentar código, escribir un README de módulo, o diga que algo no se
  entiende.
allowed-tools: Read Grep Glob
---

## Instrucciones

La documentación responde tres preguntas, en este orden:

### 1 · ¿Qué problema resuelve?

Una o dos frases. Escríbelas para alguien que llega al repositorio por
primera vez y no sabe por qué existe este módulo.

### 2 · ¿Cómo se usa?

Un ejemplo completo que funcione al copiarlo. No un fragmento que asuma
configuración no documentada.

### 3 · ¿Qué hay que saber para no romperlo?

- Invariantes que el módulo asume
- Efectos secundarios no obvios
- Dependencias con otras partes del sistema
- Decisiones de diseño que parecen raras y no lo son

## Reglas

**No documentes lo que el código ya dice.** Un comentario que repite el
nombre de la función es ruido:

    ❌  # Obtiene el usuario por id
        def obtener_usuario_por_id(id):

**Documenta lo que el código no puede decir:** por qué se eligió este
enfoque, qué se intentó antes, qué pasa si alguien cambia este orden.

**Sin información con fecha de caducidad.** Nada de "actualmente",
"por ahora", versiones concretas ni nombres de personas.

## Formato

Si el proyecto ya tiene un formato de documentación, síguelo.
Si no, usa markdown con esta estructura:

    # <Nombre del módulo>

    <Qué problema resuelve, 1-2 frases>

    ## Uso

    <ejemplo completo y copiable>

    ## Consideraciones

    <invariantes, efectos, decisiones de diseño>

<!-- Grado de libertad: ALTA. El criterio sobre qué merece documentarse es el valor. -->
