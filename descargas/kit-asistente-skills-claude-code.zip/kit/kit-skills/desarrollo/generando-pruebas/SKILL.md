---
description: Genera pruebas para código existente siguiendo las convenciones
  del proyecto, priorizando casos borde sobre el camino feliz. Úsala cuando
  el usuario pida pruebas, tests, cobertura, o diga que le falta probar algo.
allowed-tools: Read Grep Glob
---

## Instrucciones

### 1 · Antes de escribir nada, mira cómo prueba el proyecto

Busca las pruebas existentes y detecta:

- Qué corredor de pruebas se usa
- Cómo se nombran los archivos y los casos
- Si usan fixtures, factories o datos en línea
- Cómo se manejan los dobles de prueba

**Sigue esas convenciones aunque prefieras otras.** Una prueba que no se
parece a las demás del proyecto es una prueba que nadie mantiene.

### 2 · Prioriza en este orden

1. **Casos borde**: colecciones vacías, nulos, valores límite, entradas malformadas
2. **Errores esperados**: qué pasa cuando la dependencia falla
3. **Camino feliz**: el caso normal
4. **Regresiones**: si el usuario menciona un bug, la prueba que lo habría atrapado

El camino feliz va tercero a propósito. Es el que ya funciona.

### 3 · Una aserción por concepto

Cada prueba verifica un comportamiento. Si necesitas "y además" para
describirla, son dos pruebas.

### 4 · Nombres que describen el comportamiento

    ❌  test_usuario_1
    ✅  test_rechaza_email_sin_arroba

El nombre debe decir qué se rompió cuando la prueba falla en CI, sin
tener que abrir el archivo.

## Qué NO hacer

- No pruebes implementación: si refactorizar rompe la prueba sin cambiar
  comportamiento, la prueba está mal
- No uses dobles para lo que puedes probar de verdad
- No escribas pruebas que siempre pasan

## Salida

Escribe las pruebas en el archivo que corresponda según la convención del
proyecto. Al final, lista en dos o tres líneas qué quedó sin cubrir y por qué.

<!-- Grado de libertad: MEDIA. Convención del proyecto manda, contenido libre. -->
