---
description: Revisa un pull request o un diff contra las convenciones del
  proyecto y señala lo que falta antes de pedir aprobación. Úsala cuando el
  usuario pida revisar un PR, revisar su diff, pregunte si su cambio está
  listo para subir, o mencione code review.
allowed-tools: Read Grep
---

## Cambios a revisar

!`git diff origin/main...HEAD 2>/dev/null || git diff HEAD`

## Archivos tocados

!`git diff --name-only origin/main...HEAD 2>/dev/null || git diff --name-only HEAD`

## Instrucciones

Revisa en este orden y detente en el primer bloqueante que encuentres.

### 1 · Bloqueantes

Reporta y detente si encuentras alguno:

- Credenciales, tokens o cadenas de conexión en el código
- Datos personales o de cliente en pruebas, fixtures o comentarios
- Cambios en interfaces públicas sin actualizar a quien las consume
- Borrado de pruebas sin reemplazo

### 2 · Correctitud

- Casos borde sin cubrir: colecciones vacías, nulos, valores límite
- Manejo de errores ausente en operaciones que pueden fallar
- Condiciones de carrera o acceso concurrente no protegido
- Aritmética con redondeo, divisiones por cero, desbordamientos

### 3 · Mantenibilidad

- Valores hardcodeados que deberían ser configuración
- Duplicación de lógica que ya existe en el proyecto
- Nombres que no dicen lo que la cosa hace
- Funciones que hacen más de una cosa

### 4 · Pruebas

- ¿Hay prueba para cada rama nueva de comportamiento?
- ¿Alguna prueba existente quedó desactualizada por este cambio?
- ¿Las pruebas prueban comportamiento o implementación?

## Formato del reporte

    BLOQUEANTE  <archivo>:<línea> — <qué está mal y por qué>
    IMPORTANTE  <archivo>:<línea> — <qué está mal>
    MENOR       <archivo>:<línea> — <sugerencia>

Ordena por severidad. Si no hay nada en una categoría, omítela en vez de
escribir "ninguno".

No reescribas el código. Señala y explica; quien decide es quien lo escribió.

Si el diff está vacío, dilo en una línea y detente.

<!-- Grado de libertad: ALTA. El criterio de revisión es el valor. -->
