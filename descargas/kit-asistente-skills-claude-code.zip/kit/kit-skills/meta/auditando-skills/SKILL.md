---
description: Audita las skills de un directorio contra las reglas de
  nomenclatura, descripción, estructura y seguridad, y reporta qué corregir.
  Úsala cuando el usuario pida revisar sus skills, auditar el directorio de
  skills, o pregunte por qué alguna de sus skills no funciona bien.
allowed-tools: Read Grep Glob
---

## Instrucciones

Recorre cada `SKILL.md` del directorio indicado y evalúa los siguientes
puntos. Reporta solo lo que falla.

### Frontmatter

- ¿El `---` de apertura es la **primera línea** del archivo? Si no, todo el
  archivo se trata como contenido y la skill no tiene metadatos
- ¿Existe `description`?
- ¿`description` más `when_to_use` suman menos de 1,536 caracteres?
- Si hay `name`: solo minúsculas, números y guiones, máximo 64 caracteres,
  sin las palabras `anthropic` ni `claude`

### Descripción

- ¿Está en tercera persona? Marca cualquier `te puedo`, `puedo ayudarte`,
  `te ayudo`, `you can`, `I can`
- ¿Incluye la parte del **cuándo**? Busca `úsala cuando`, `use when`, o
  equivalente
- ¿El caso principal está al inicio, o la primera oración es genérica?
- ¿Usa términos vagos como `documentos`, `archivos`, `datos`, `cosas`
  sin acotar?

### Nombre del directorio

- ¿Está en gerundio y describe una actividad?
- ¿Es genérico? Marca `helper`, `utils`, `tools`, `misc`, `general`,
  `mi-skill`, `test`

### Estructura

- ¿`SKILL.md` por debajo de 500 líneas?
- ¿Las referencias a otros archivos van a **un solo nivel**? Si
  `reference.md` referencia a un tercer archivo, es una cadena
- ¿Hay rutas absolutas o con barra invertida?
- ¿Las rutas a archivos propios usan `${CLAUDE_SKILL_DIR}`?
- ¿Declara su grado de libertad en un comentario final?

### Seguridad

- ¿`allowed-tools` pide más de lo necesario? Un `Bash` pelado sin patrón
  es un hallazgo
- Si la skill ejecuta acciones con efectos —desplegar, commitear, enviar,
  borrar— ¿lleva `disable-model-invocation: true`?
- ¿Hay credenciales, tokens, rutas de infraestructura o datos de cliente?
- ¿Los comandos `!` que pueden salir con código distinto de cero llevan
  `|| true`?

### Contenido

- ¿Explica cosas que Claude ya sabe?
- ¿Tiene información con fecha de caducidad: versiones concretas, precios,
  nombres en puestos, "actualmente", "por ahora"?
- ¿La terminología es consistente de principio a fin?
- ¿Ofrece varias alternativas donde debería dar una?

### Solapamiento

Compara las descripciones entre sí. Dos skills cuyas descripciones cubren
el mismo territorio se estorban: se dispara la equivocada de forma
inconsistente. Repórtalo con las dos involucradas.

## Formato del reporte

    ## <nombre-de-la-skill>

    BLOQUEANTE  <qué está mal> → <cómo se corrige>
    IMPORTANTE  <qué está mal> → <cómo se corrige>
    MENOR       <qué está mal>

**Bloqueante:** frontmatter que no parsea, descripción sin el "cuándo",
descripción en 1ª o 2ª persona, secretos, acción con efectos sin
`disable-model-invocation`.

Si una skill no tiene hallazgos, escríbela con un `✓` y nada más.

Cierra con:

    <n> skills · <n> sin hallazgos · <n> bloqueantes · <n> importantes
    Solapamientos detectados: <lista de pares, o ninguno>

<!-- Grado de libertad: MEDIA. Checklist fijo, juicio libre sobre severidad. -->
