---
description: Convierte la conversación actual en una skill de Claude Code
  reutilizable, analizando qué contexto hizo falta y qué correcciones
  revelaron huecos. Úsala cuando el usuario diga que quiere convertir esto
  en una skill, guardar este patrón, no volver a explicar lo mismo, o
  destilar la conversación.
disable-model-invocation: true
---

> Esta skill se invoca manualmente con `/destilando-conversacion` al final
> de una conversación productiva.

## Fase 1 · Analiza antes de escribir

Responde estas seis preguntas en una lista corta. No escribas el SKILL.md
todavía.

1. **¿Cuál fue la tarea real?** Enúnciala como actividad, en gerundio.

2. **¿Qué contexto tuvo que dar el usuario** que tú no sabías de entrada?
   Sepáralo en (a) convenciones o criterios suyos, y (b) hechos del proyecto.

3. **¿En qué momentos te corrigió**, y qué revela cada corrección sobre lo
   que faltaba en la instrucción inicial?

4. **¿Qué parte de lo explicado era innecesaria** porque ya lo sabías?

5. **¿Qué tan frágil es la tarea?** Alta libertad si varios caminos llegan a
   un buen resultado; media si hay un patrón preferido; baja si un paso en
   falso rompe algo.

6. **¿Con qué frases exactas pediría el usuario esta tarea la próxima vez?**
   Tres variantes, en sus palabras, no en lenguaje de manual.

## Fase 2 · Construye el SKILL.md

### Nombre

Gerundio que describe la actividad, minúsculas con guiones, máximo 64
caracteres, sin `anthropic` ni `claude`. Nunca genérico.

### Descripción

Fórmula: `[qué hace]. Úsala cuando [cuándo usarla].`

- Tercera persona, siempre
- Caso principal al inicio
- Los disparadores salen de la pregunta 6, no de lenguaje formal
- Tope de 1,536 caracteres

### Cuerpo

- Solo lo de la pregunta 2. Nada de lo de la pregunta 4
- Instrucciones permanentes, no pasos de un solo uso: el contenido se queda
  en contexto turno tras turno
- Enuncia qué hacer, no narres por qué
- Si la pregunta 5 dio baja libertad: comando exacto y prohibición explícita
  de variarlo
- Por debajo de 100 líneas

### Frontmatter

- `allowed-tools` solo si ejecuta comandos, con el patrón más acotado posible
- `disable-model-invocation: true` si la tarea tiene efectos irreversibles
- Cierra el cuerpo con `<!-- Grado de libertad: ALTA/MEDIA/BAJA -->`

## Fase 3 · Entrega

1. El análisis de las seis preguntas
2. El `SKILL.md` completo, en un bloque de código
3. El comando `mkdir -p` para crear la carpeta
4. Tres evaluaciones: dos que **deben** disparar la skill y una que **no**
   debe dispararla, con el resultado esperado de cada una

No ofrezcas alternativas. Da una versión, y di qué decisión tomaste en los
puntos donde había más de un camino.

<!-- Grado de libertad: MEDIA. Método fijo, contenido depende de la conversación. -->
