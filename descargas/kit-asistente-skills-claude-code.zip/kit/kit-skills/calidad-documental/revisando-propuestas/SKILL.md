---
description: Revisa una propuesta técnico-comercial contra los requisitos de
  las bases y marca cada punto sin evidencia. Úsala cuando el usuario
  mencione propuesta, licitación, bases, anexo técnico, matriz de
  cumplimiento, o pida revisar antes de entregar.
allowed-tools: Read Grep
---

## Instrucciones

### 1 · Extrae los requisitos

Si el usuario dio las bases o el anexo técnico, extrae cada requisito como
una línea verificable. Si solo dio la propuesta, dilo y pide las bases: sin
ellas esto es una revisión de estilo, no de cumplimiento.

Numera los requisitos con la numeración del documento original, no con una
propia. Quien evalúa busca por su número.

### 2 · Para cada requisito, encuentra la evidencia

| Estado | Significa |
|---|---|
| **CUMPLE** | La propuesta lo atiende explícitamente y se puede señalar dónde |
| **PARCIAL** | Lo menciona pero no lo demuestra, o lo atiende a medias |
| **NO CUMPLE** | No aparece |
| **AMBIGUO** | El requisito se puede interpretar de dos formas y la propuesta elige una sin decirlo |

La evidencia es una referencia concreta: sección y página. "Se aborda en
la propuesta" no es evidencia.

### 3 · Revisa los riesgos de compromiso

Aparte del cumplimiento, marca:

- Niveles de servicio aceptados sin reserva
- Penalizaciones sin tope
- Fechas comprometidas sin condicionante
- Alcance que excede lo que las bases piden (regalar trabajo también es un riesgo)
- Cifras que no cuadran entre el apartado técnico y el económico

### 4 · Revisa la consistencia entre apartados

Es donde más se cae una propuesta:

- ¿El perfil que promete el apartado técnico está costeado en el económico?
- ¿Los plazos del cronograma coinciden con los del texto?
- ¿La razón social, RFC y datos fiscales son los mismos en todos los anexos?
- ¿Las firmas requeridas están identificadas?

## Formato

    ## Matriz de cumplimiento

    | Req. | Descripción | Estado | Evidencia | Acción |
    |---|---|---|---|---|

    ## Riesgos de compromiso

    | Riesgo | Dónde | Severidad | Recomendación |
    |---|---|---|---|

    ## Inconsistencias entre apartados

    | Qué | Dice en A | Dice en B |
    |---|---|---|

Cierra con:

    <n> requisitos · <n> cumple · <n> parcial · <n> no cumple · <n> ambiguo
    VEREDICTO: <entregable / requiere corrección>

<!-- Grado de libertad: MEDIA. Método fijo, criterio libre. -->
