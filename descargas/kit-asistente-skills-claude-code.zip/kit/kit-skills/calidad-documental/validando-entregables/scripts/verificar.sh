#!/usr/bin/env bash
# Verificación mecánica de un documento entregable.
# Reporta hechos. El juicio lo pone Claude.
set -uo pipefail

DOC="${1:-}"
if [ -z "$DOC" ] || [ ! -f "$DOC" ]; then
  echo "USO: verificar.sh <archivo>"
  exit 0
fi

echo "ARCHIVO: $DOC"
echo "LINEAS: $(wc -l < "$DOC" | tr -d ' ')"
echo "PALABRAS: $(wc -w < "$DOC" | tr -d ' ')"
echo ""

echo "== MARCADORES SIN LLENAR =="
if grep -nEi '\bTODO\b|\bTBD\b|\bXXX+\b|lorem ipsum|\[pendiente\]|\[insertar|\[completar|<placeholder>|PENDIENTE DE' "$DOC"; then
  :
else
  echo "  ninguno"
fi
echo ""

echo "== SECCIONES Y JERARQUIA =="
grep -nE '^#{1,6} ' "$DOC" | head -60 || echo "  sin encabezados markdown"
echo ""

echo "== SECCIONES POSIBLEMENTE VACIAS =="
awk '
  function nivel(s) { match(s, /^#+/); return RLENGTH }
  /^#{1,6} / {
    n = nivel($0)
    # un encabezado sin cuerpo solo cuenta como vacio si el siguiente
    # no es un subnivel suyo
    if (titulo != "" && cuerpo == 0 && n <= prev) print "  linea " nlin ": " titulo
    titulo = $0; nlin = NR; cuerpo = 0; prev = n; next
  }
  /[^[:space:]]/ { if (titulo != "") cuerpo = 1 }
  END { if (titulo != "" && cuerpo == 0) print "  linea " nlin ": " titulo }
' "$DOC" | head -20
echo "  (vacio = encabezado sin contenido ni subsecciones)"
echo ""

echo "== REFERENCIAS CRUZADAS DECLARADAS =="
grep -noEi '(ver|v[eé]ase|consulte|seg[uú]n) (la |el )?(secci|apartado|anexo|cap[ií]tulo|tabla|figura|cl[aá]usula)[^ ]* [0-9IVXivx][0-9IVXivxA-Za-z.]*' "$DOC" | head -25 || echo "  ninguna"
echo ""

echo "== FECHAS ENCONTRADAS =="
grep -noE '[0-9]{1,2}[/-][0-9]{1,2}[/-][0-9]{2,4}|[0-9]{4}-[0-9]{2}-[0-9]{2}' "$DOC" | head -25 || echo "  ninguna"
echo ""

echo "== LENGUAJE DE COMPROMISO ABSOLUTO =="
grep -nEi '\bgarantiza(mos|r|do)?\b|\bsiempre\b|\bnunca\b|\ben todos los casos\b|\bsin excepci[oó]n\b|\bal 100%\b|\btotalmente\b' "$DOC" | head -25 || echo "  ninguno"
echo ""

echo "== CIFRAS CON MONEDA O PORCENTAJE =="
grep -noE '\$[0-9][0-9,.]*|[0-9][0-9,.]*%|MXN ?[0-9][0-9,.]*|USD ?[0-9][0-9,.]*' "$DOC" | head -30 || echo "  ninguna"
echo ""

echo "== TABLAS =="
echo "  filas de tabla detectadas: $(grep -cE '^\|' "$DOC" 2>/dev/null; true)"
