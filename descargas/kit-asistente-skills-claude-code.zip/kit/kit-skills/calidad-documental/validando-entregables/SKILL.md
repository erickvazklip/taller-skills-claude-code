---
description: Valida que un documento entregable cumpla los criterios de
  completitud, consistencia y formato antes de enviarlo al cliente. Úsala
  cuando el usuario pida revisar un documento, validar un entregable,
  pregunte si un documento está listo para enviar, o mencione control de
  calidad documental.
allowed-tools: Read Grep Bash(bash ${CLAUDE_SKILL_DIR}/scripts/*)
---

## Instrucciones

### 1 · Verificación mecánica primero

    bash ${CLAUDE_SKILL_DIR}/scripts/verificar.sh <archivo>

El script detecta marcadores sin llenar, referencias rotas y secciones
vacías. Lo que reporta son hechos, no opiniones: corrígelos antes de
pasar a la revisión de contenido.

### 2 · Completitud

Para cada sección del documento:

- ¿Existe?
- ¿Tiene contenido real o solo un encabezado?
- ¿Contiene marcadores sin llenar: `TODO`, `XXX`, `[pendiente]`, `<...>`, `Lorem`?
- ¿Las tablas tienen todas sus celdas?

### 3 · Consistencia

- **Terminología**: ¿el mismo concepto se llama igual en todo el documento?
- **Cifras**: ¿los totales suman? ¿el mismo dato aparece igual en todos lados?
- **Fechas**: ¿son coherentes entre sí? ¿alguna está en el pasado sin querer?
- **Nombres**: ¿la razón social, los nombres propios y los cargos están bien escritos y son los mismos en todo el documento?
- **Referencias cruzadas**: ¿"ver sección 4.2" apunta a algo que existe?

### 4 · Riesgo de compromiso

Esta es la parte que más cuesta cuando falla. Marca:

- Compromisos de fecha sin condicionante
- Cifras sin fuente ni supuesto declarado
- Afirmaciones absolutas: "garantizamos", "siempre", "en todos los casos"
- Alcance que excede lo acordado
- Penalizaciones o niveles de servicio aceptados implícitamente

### 5 · Formato

- Jerarquía de encabezados sin saltos de nivel
- Numeración continua en listas y secciones
- Unidades y formato numérico consistentes
- Tablas con encabezado

## Formato del reporte

    BLOQUEANTE  <sección> — <qué falta y por qué impide enviar>
    IMPORTANTE  <sección> — <inconsistencia o riesgo>
    MENOR       <sección> — <formato o estilo>

Ordena por severidad. Omite las categorías vacías.

Cierra con un veredicto de una línea:

    LISTO PARA ENVIAR  /  REQUIERE CORRECCIÓN (<n> bloqueantes)

No reescribas el documento. Señala y explica.

<!-- Grado de libertad: MEDIA. Checklist fijo, juicio libre sobre severidad. -->
