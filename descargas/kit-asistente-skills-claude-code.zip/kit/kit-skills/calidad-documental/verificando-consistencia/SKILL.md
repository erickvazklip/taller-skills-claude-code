---
description: Verifica que un conjunto de documentos relacionados diga lo
  mismo entre sí: cifras, fechas, nombres y compromisos. Úsala cuando el
  usuario tenga varios documentos de un mismo proyecto, mencione anexos,
  o pregunte si todo cuadra entre sí.
allowed-tools: Read Grep Glob
---

## Instrucciones

Esta skill no revisa un documento: revisa **el conjunto**. El error que
busca es el que solo se ve comparando.

### 1 · Construye el inventario

Lista los documentos a comparar y qué rol tiene cada uno: contrato,
anexo técnico, anexo económico, cronograma, matriz de cumplimiento.

Si falta alguno que los demás referencian, dilo antes de seguir.

### 2 · Compara por dimensión

**Cifras.** Toma cada monto, porcentaje y cantidad, y busca sus
apariciones en todos los documentos. Un monto que aparece distinto en dos
lugares es un hallazgo bloqueante.

**Fechas.** Fechas de inicio, entrega, vigencia y hitos. Verifica además
que sean coherentes: que la entrega no sea anterior al inicio, que la
vigencia cubra el cronograma.

**Nombres y datos fiscales.** Razón social, RFC, domicilio, representante
legal, cargos. Un carácter distinto entre anexos es motivo de descalificación
en un proceso formal.

**Compromisos.** Niveles de servicio, plazos de respuesta, penalizaciones,
entregables. Lo prometido en un documento tiene que estar costeado y
calendarizado en los otros.

**Terminología.** Si el contrato dice "Prestador" y el anexo dice
"Proveedor", uno de los dos está mal.

### 3 · Clasifica cada hallazgo

| Severidad | Criterio |
|---|---|
| **BLOQUEANTE** | Cifras o datos fiscales que no coinciden; compromiso sin respaldo |
| **IMPORTANTE** | Fechas incoherentes; terminología inconsistente en cláusulas |
| **MENOR** | Formato, redondeo, estilo |

## Formato

    | # | Dimensión | Hallazgo | Doc A dice | Doc B dice | Severidad |
    |---|---|---|---|---|---|

Ordena por severidad.

Para cada bloqueante, agrega una línea con **cuál de los dos es el correcto**
si se puede determinar, o la pregunta que hay que hacer si no.

## Al final

    <n> documentos comparados · <n> hallazgos
    <n> bloqueantes · <n> importantes · <n> menores

Si no hay hallazgos, dilo en una línea. No inventes inconsistencias para
llenar el reporte.

<!-- Grado de libertad: ALTA. El criterio de qué cuenta como inconsistencia es el valor. -->
