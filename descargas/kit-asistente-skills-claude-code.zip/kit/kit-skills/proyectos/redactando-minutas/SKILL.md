---
description: Convierte notas crudas de una reunión en una minuta con acuerdos,
  responsables y fechas. Úsala cuando el usuario pegue notas de junta, pida
  una minuta, un acta, un resumen de reunión, o pregunte en qué quedamos.
---

## Instrucciones

Recibes notas desordenadas. Produce una minuta con esta estructura:

    # <Tema> · <fecha>

    **Asistentes:** <lista, o "no registrados">

    ## Decisiones

    - <qué se decidió> — decidido por <quién>

    ## Acuerdos

    | Qué | Quién | Para cuándo |
    |---|---|---|
    | <acción concreta, en imperativo> | <nombre> | <fecha o "sin fecha"> |

    ## Temas abiertos

    - <lo que quedó sin resolver y quién lo retoma>

    ## Contexto relevante

    <solo si hay algo que alguien ausente necesitaría para entender lo anterior>

## Reglas

**Separa decisión de acuerdo.** Una decisión es algo que ya se resolvió.
Un acuerdo es algo que alguien va a hacer. Confundirlos es el error más
común en las minutas.

**Todo acuerdo necesita dueño.** Si las notas no dicen quién, escribe
`SIN DUEÑO` en mayúsculas. Es información, no un hueco.

**Toda fecha se escribe explícita.** "La próxima semana" se convierte en
la fecha concreta. Si no puedes calcularla, escribe `SIN FECHA`.

**No inventes.** Si las notas son ambiguas sobre quién dijo qué o en qué
se quedó, escribe la ambigüedad tal cual: "queda pendiente confirmar si X
o Y". No resuelvas por tu cuenta lo que la reunión no resolvió.

**Omite lo que no aporta.** Una minuta no es una transcripción. Si algo
se discutió pero no produjo decisión, acuerdo ni tema abierto, no va.

## Al final

Agrega una línea con el conteo:

    <n> decisiones · <n> acuerdos (<n> sin dueño, <n> sin fecha) · <n> temas abiertos

Los sin dueño y sin fecha son la parte accionable: quien lee la minuta
sabe qué tiene que cerrar.

<!-- Grado de libertad: MEDIA. Estructura fija, juicio libre sobre qué entra. -->
