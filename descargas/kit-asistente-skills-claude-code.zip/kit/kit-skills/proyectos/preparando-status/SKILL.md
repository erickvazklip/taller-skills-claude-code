---
description: Redacta el reporte de avance de un proyecto para dirección,
  con semáforo, desviaciones y decisiones que se necesitan. Úsala cuando el
  usuario pida un status, un reporte de avance, un update para dirección,
  o prepare un comité de seguimiento.
---

## Instrucciones

El reporte se escribe para alguien que tiene cinco minutos y varios
proyectos. Estructura:

    # <Proyecto> · Avance al <fecha>

    ## Semáforo: 🟢 / 🟡 / 🔴

    <Una frase que justifique el color. Si es amarillo o rojo, la frase
    dice qué lo causa, no qué se está haciendo al respecto.>

    ## Lo que avanzó

    - <entregable completado, con evidencia verificable>

    ## Lo que se movió

    | Compromiso | Fecha original | Fecha nueva | Por qué |
    |---|---|---|---|

    ## Decisiones que necesito

    | Decisión | Quién decide | Para cuándo | Qué pasa si no se decide |
    |---|---|---|---|

    ## Riesgos activos

    - <solo los que cambiaron de estado desde el último reporte>

## Criterio del semáforo

| Color | Significa |
|---|---|
| 🟢 **Verde** | En fecha y alcance. Sin decisiones pendientes que bloqueen |
| 🟡 **Amarillo** | Hay desviación recuperable, o hay una decisión pendiente con fecha límite |
| 🔴 **Rojo** | La fecha o el alcance comprometido ya no son alcanzables sin cambiar algo |

**El semáforo se pone antes de escribir el resto.** Si lo decides al final,
vas a justificar el verde.

## Reglas

**Sin adjetivos de avance.** "Buen progreso" no dice nada. Escribe qué se
completó y qué falta.

**Lo que se movió va aunque sea incómodo.** Un status que oculta
deslizamientos deja de ser útil la segunda vez que alguien lo nota.

**Las decisiones pendientes son la parte más importante.** Es lo único que
el lector puede hacer por ti. Cada una lleva fecha límite y consecuencia
de no decidir.

**No repitas el reporte anterior.** Solo lo que cambió.

**Si un dato no lo tienes, escribe `SIN DATO`.** No estimes.

<!-- Grado de libertad: MEDIA. Estructura fija, contenido libre. -->
