---
description: Descompone un requerimiento o una propuesta en entregables,
  tareas y supuestos, señalando lo que está indefinido. Úsala cuando el
  usuario pida desglosar un alcance, hacer un WBS, estimar un proyecto,
  o mencione que un requerimiento está muy general.
---

## Instrucciones

### 1 · Separa lo definido de lo asumido

Antes de desglosar nada, lista en dos columnas:

    ESTÁ DEFINIDO          ESTOY ASUMIENDO
    <lo que dice el        <lo que hace falta para
     requerimiento>         poder estimar y no está>

**La columna derecha es la más valiosa del ejercicio.** Cada supuesto ahí
es una conversación que hay que tener antes de comprometer una fecha.

### 2 · Desglosa por entregable, no por actividad

    ❌  Análisis, diseño, desarrollo, pruebas
    ✅  Módulo de autenticación funcionando en staging
        Reporte de conciliación mensual generándose solo

Un entregable es algo que se puede enseñar y que alguien puede aceptar o
rechazar. "Análisis" no se puede aceptar.

### 3 · Tres niveles, no más

    Entregable
    └── Componente
        └── Tarea (1 a 5 días)

Si una tarea pasa de cinco días, no está desglosada: está escondiendo algo.
Si necesitas un cuarto nivel, probablemente el entregable son dos.

### 4 · Marca las dependencias y lo que no controlas

Para cada entregable:

- De qué otro entregable depende
- Qué necesita de terceros: accesos, aprobaciones, datos, ambientes
- Qué es camino crítico

## Formato

    ## Entregable 1 · <nombre>

    **Criterio de aceptación:** <cómo se sabe que está terminado>
    **Depende de:** <entregable, o "nada">
    **Requiere de terceros:** <qué y de quién, o "nada">

    | Componente | Tarea | Días | Notas |
    |---|---|---|---|

## Reglas

**Todo entregable lleva criterio de aceptación.** Sin él, el desglose no
sirve para negociar ni para cerrar.

**Los supuestos se escriben aunque sean obvios.** Lo obvio para ti no lo
es para quien firma.

**Lo que no se puede estimar se marca `REQUIERE DEFINICIÓN`** con la
pregunta concreta que hay que responder. No pongas un número inventado.

**No incluyas contingencia dentro de las tareas.** Va aparte, explícita,
para que sea negociable.

## Al final

    <n> entregables · <n> tareas · <n> supuestos · <n> requieren definición

<!-- Grado de libertad: MEDIA. Método fijo, contenido depende del caso. -->
