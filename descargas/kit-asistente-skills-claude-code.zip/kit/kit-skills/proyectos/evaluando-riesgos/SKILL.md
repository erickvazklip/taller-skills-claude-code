---
description: Construye o actualiza el registro de riesgos de un proyecto con
  probabilidad, impacto, mitigación y dueño. Úsala cuando el usuario mencione
  riesgos, qué puede salir mal, un risk register, o pida evaluar un plan
  antes de comprometerlo.
---

## Instrucciones

### 1 · Identifica por categoría

Recorre estas categorías. No todas aplican a todo proyecto, pero
recorrerlas evita puntos ciegos:

| Categoría | Pregunta que dispara el riesgo |
|---|---|
| **Alcance** | ¿Qué no está definido y alguien asume distinto? |
| **Técnico** | ¿Qué no hemos hecho antes? ¿De qué dependemos y no controlamos? |
| **Recursos** | ¿Quién es irreemplazable en este plan? |
| **Calendario** | ¿Qué depende de qué? ¿Dónde está el camino crítico? |
| **Externo** | ¿Qué proveedor, aprobación o tercero nos puede frenar? |
| **Operación** | ¿Qué pasa el día después de entregar? |

### 2 · Clasifica

**Probabilidad:** Alta (pasa en la mayoría de proyectos así) · Media (ha
pasado antes) · Baja (sería inusual).

**Impacto:** Alto (compromete el objetivo o la fecha) · Medio (cuesta
retrabajo significativo) · Bajo (molesta, se absorbe).

### 3 · Para cada riesgo, escribe la mitigación y el disparador

La mitigación es lo que haces **antes** de que pase. El disparador es la
señal observable de que está pasando.

Un riesgo sin disparador no se puede monitorear: nadie sabe cuándo activar
el plan.

## Formato

    | # | Riesgo | Prob | Imp | Mitigación | Disparador | Dueño |
    |---|---|---|---|---|---|---|

Ordena por impacto descendente, luego por probabilidad.

## Reglas

**Un riesgo se enuncia como causa y efecto**, no como un tema:

    ❌  Riesgo de integración
    ✅  Si la API del proveedor cambia sin aviso, la sincronización
        se cae y perdemos un día en diagnosticar

**Los riesgos Alta/Alto llevan además plan de contingencia**: qué se hace
si ya pasó, no solo cómo evitarlo.

**Todo riesgo tiene dueño nombrado.** "El equipo" no es un dueño.

**Distingue riesgo de problema.** Si ya está pasando, no es riesgo: es un
problema y va a otra lista. Dilo explícitamente cuando lo detectes.

## Al final

    <n> riesgos · <n> alta/alto (requieren contingencia) · <n> sin dueño

<!-- Grado de libertad: MEDIA. Marco fijo, contenido depende del proyecto. -->
