# Kit del asistente
## Webinar · Skills con Claude Code

OmniSys · Dirección de Innovación y Preventa

---

## Si solo tienes 20 minutos hoy

1. Copia una skill del kit a tu máquina:
   ```bash
   cp -r kit-skills/desarrollo/redactando-commits ~/.claude/skills/
   ```
2. Prepara cualquier cambio con `git add` y pide: `dame un mensaje de commit para esto`
3. Fíjate en que **no escribiste `/`**. Se disparó sola. Ese es todo el mecanismo.
4. Abre `05-PRIMEROS-30-DIAS.md` y haz el Día 1.

Lo demás puede esperar. Eso no.

---

## Qué hay aquí

### Para leer · PDF

| Archivo | Qué es |
|---|---|
| **PDF/01-Manual-Skills-Claude-Code.pdf** | Manual completo, 17 páginas. Fundamentos, cómo se crean, políticas y buenas prácticas. Con índice navegable |
| **PDF/02-Tarjeta-de-referencia.pdf** | Dos páginas. **Imprímela a doble cara** y pégala junto al monitor |
| **PDF/03-Primeros-30-dias.pdf** | Guía de adopción, semana por semana |

### Para copiar y usar · Markdown

| Archivo | Qué es |
|---|---|
| **03-PROMPT-DESTILADOR.md** | El prompt que convierte una conversación en skill. En md porque se copia y se pega |
| **kit-skills/** | Trece skills listas. Son archivos `SKILL.md`: por definición van en markdown |
| **04-PLANTILLAS/** | Tres puntos de partida en blanco |

### Todo junto

| Archivo | Qué es |
|---|---|
| **KIT-COMPLETO.html** | Todo el material navegable en un solo archivo, con botón de copiar en cada bloque de código |

> **Por qué esta división.** Lo que se lee de corrido va en PDF: tipografía cuidada, índice y numeración. Lo que se copia, se pega o se instala se queda en markdown, que es su formato nativo.

---

## El kit de skills

Trece skills funcionando, organizadas por dominio. **Léelas antes de escribir
las tuyas**: son el mejor material de estudio que hay, porque muestran las
decisiones, no solo las reglas.

### Ciclo de desarrollo de software

| Skill | Qué hace | Grado |
|---|---|---|
| `revisando-prs` | Revisa un PR contra las convenciones, con severidades | Alta |
| `redactando-commits` | Mensaje de commit convencional desde lo preparado | Media |
| `generando-pruebas` | Pruebas siguiendo la convención del proyecto, casos borde primero | Media |
| `documentando-modulos` | Documenta qué problema resuelve, no qué hace línea por línea | Alta |

### Gestión de proyectos

| Skill | Qué hace | Grado |
|---|---|---|
| `redactando-minutas` | Notas crudas → acuerdos con dueño y fecha | Media |
| `evaluando-riesgos` | Registro de riesgos con probabilidad, mitigación y disparador | Media |
| `preparando-status` | Reporte de avance con semáforo y decisiones que necesitas | Media |
| `desglosando-alcance` | Requerimiento → entregables, tareas y supuestos | Media |

### Validación de calidad documental

| Skill | Qué hace | Grado |
|---|---|---|
| `validando-entregables` | Valida un documento antes de enviarlo. **Incluye script** | Media |
| `revisando-propuestas` | Matriz de cumplimiento contra bases de licitación | Media |
| `verificando-consistencia` | Compara varios documentos entre sí: cifras, fechas, datos | Alta |

### Meta · skills sobre skills

| Skill | Qué hace | Grado |
|---|---|---|
| `auditando-skills` | Audita tus skills contra las reglas del manual | Media |
| `destilando-conversacion` | El prompt destilador, como skill invocable | Media |

---

## Instalación

### Una skill

```bash
cp -r kit-skills/desarrollo/revisando-prs ~/.claude/skills/
```

### Una categoría completa

```bash
cp -r kit-skills/calidad-documental/* ~/.claude/skills/
```

### Para todo un equipo, en un repositorio

```bash
mkdir -p .claude/skills
cp -r kit-skills/desarrollo/* .claude/skills/
git add .claude/skills && git commit -m "add: kit de skills de desarrollo"
```

Quien clone el repositorio las tiene. Sin instalación.

### Verifica

Abre Claude Code y escribe `/skills`. Deben aparecer.

---

## Cómo están construidas estas skills

Todas siguen las mismas reglas, y por eso sirven de ejemplo:

- **Nombre en gerundio** que describe la actividad
- **Descripción en tercera persona**, con qué hace **y** cuándo usarla, usando las palabras que la gente escribe de verdad
- **Grado de libertad declarado** en un comentario al final
- **Sin información con fecha de caducidad**
- **`allowed-tools` acotado** al mínimo necesario
- **Menos de 100 líneas** cada una

Si abres cualquiera y comparas contra la sección §12 del manual, vas a ver
cada política aplicada.

---

## Advertencia sobre la vigencia

El contenido técnico está verificado contra la documentación oficial de
Claude Code al momento de escribirse. **Claude Code cambia rápido.**

Antes de tomar una decisión importante basada en un detalle de este material
—campos del frontmatter, comandos de diagnóstico, límites numéricos— verifica
contra la fuente:

- [Mejores prácticas para la creación de Skills](https://platform.claude.com/docs/es/agents-and-tools/agent-skills/best-practices)
- [Extend Claude with skills](https://code.claude.com/docs/en/skills)
- [Agent Skills overview](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview)
- [agentskills.io](https://agentskills.io) — estándar abierto

---

## Licencia de uso

Este material es de OmniSys S.A. de C.V. y se entrega a los asistentes del
webinar para su uso profesional. Las skills del kit puedes copiarlas,
modificarlas y usarlas en tu trabajo sin restricción.

---

## Versión navegable

**KIT-COMPLETO.html** contiene todo este material en un solo archivo: manual,
tarjeta, prompt destilador, guía de 30 días, las trece skills con su código
completo y las plantillas. Cada bloque de código tiene botón de copiar.

Ábrelo en cualquier navegador. Funciona sin conexión y sin JavaScript
—en ese caso se ve todo el contenido seguido, sin pestañas.

## Nota sobre las tipografías de los PDF

Los PDF usan **Poppins** para títulos y **Carlito** para texto, que es lo más
cercano al sistema tipográfico de OmniSys (Syne + IBM Plex) disponible sin
dependencias externas. Los archivos son autocontenidos: las fuentes van
incrustadas y se ven igual en cualquier equipo.
