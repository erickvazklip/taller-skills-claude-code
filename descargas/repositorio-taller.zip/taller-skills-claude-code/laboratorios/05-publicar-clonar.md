# Laboratorio 5 · Publicar y clonar
**6 minutos · individual**

## Qué vas a lograr
Sacar tu skill de tu máquina y correr la de alguien más.

## Publica

```bash
mkdir -p publicaciones/tu-usuario
cp -r ~/.claude/skills/tu-skill publicaciones/tu-usuario/
git add publicaciones/tu-usuario
git commit -m "add: tu-skill"
git push
```

Una carpeta por persona evita conflictos de merge.

## Clona

```bash
git pull
```

Elige la skill de **otra persona**.

> **Antes de ejecutarla, revisa su `allowed-tools`.** Una skill puede preaprobarse acceso amplio a herramientas. Si no entiendes por qué necesita lo que pide, pregúntale a quien la escribió antes de correrla.

```bash
cp -r publicaciones/otra-persona/su-skill ~/.claude/skills/
```

## Ejecuta

Córrela **sin que nadie te explique nada**. Ese es el punto: si necesitas explicación, la descripción no fue suficiente.

## Entrega
Pega en el chat:

```
probé <skill> de <persona> — se entendió sola: sí / no
```

El **"no"** vale más que el "sí". Es el dato que le sirve al autor.

## Terminado cuando
Publicaste la tuya y ejecutaste la de alguien más.

## Si algo falla

| Problema | Solución |
|---|---|
| Conflicto de merge | Tu carpeta debe ser única. Revisa que usaste tu usuario |
| No tienes permisos de push | Sube la skill como archivo adjunto en el chat y sigue |
| La skill de otro no corre | Revisa si depende de rutas de su máquina. Ese es el hallazgo |

## Para llevarte
Una skill que solo funciona en tu máquina es una nota personal. En el repo es infraestructura del equipo.
