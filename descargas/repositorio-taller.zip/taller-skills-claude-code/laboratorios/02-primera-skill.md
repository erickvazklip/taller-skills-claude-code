# Laboratorio 2 · Tu primera skill
**20 minutos · en pareja**

> Este es el laboratorio central del taller. Lo que construyas aquí es lo que te llevas.

## Qué vas a lograr
Una skill tuya, sobre un caso que ya repites, que se dispara sola sin que escribas `/`.

## Antes de empezar: elige tu caso

Algo que **ya hiciste esta semana** y vas a volver a hacer. No inventes un caso bonito.

Si no se te ocurre nada, toma uno:

- Resumir los cambios sin commitear y señalar lo riesgoso
- Redactar el mensaje de commit con el formato de tu equipo
- Actualizar el CHANGELOG a partir de los commits recientes
- Revisar que un README tenga las secciones que tu equipo exige

**No pierdas más de un minuto decidiendo.** Elegir el caso perfecto no es el ejercicio.

---

## Paso 1 · Claude A — resuelve a mano (8 min)

Abre una sesión y resuelve la tarea con prompting normal, sin skill:

```bash
claude
```

Pide lo que pedirías normalmente. **Fíjate en qué contexto tuviste que darle**: qué criterio, qué formato, qué te importa.

Cuando tengas un resultado que te sirva, pide:

```
crea una skill que capture este patrón
```

---

## Paso 2 · Recorte (4 min)

Claude va a generar algo más largo de lo necesario. Recórtalo:

```
quita la explicación de [lo que Claude ya sabe], eso ya lo sabes
```

```
déjalo en menos de 30 líneas
```

**Verifica las cuatro cosas:**

- [ ] Nombre en gerundio, describe la actividad: `resumiendo-cambios`, no `helper`
- [ ] La descripción dice **qué hace** y **cuándo usarla**
- [ ] Tercera persona: `Analiza...`, nunca `Te puedo ayudar...`
- [ ] Las palabras de la descripción son las que **tú** escribirías al pedirlo

---

## Paso 3 · Claude B — pruébala en limpio (6 min)

Sal y abre una sesión **nueva**:

```
/exit
```
```bash
claude
```

Pide la tarea en lenguaje natural. **No escribas `/`.**

```
¿qué cambié hoy?
```

**¿Se disparó sola?**

---

## Paso 4 · La vuelta (2 min)

**Si no se disparó:** el problema está en la descripción, casi nunca en el cuerpo. Vuelve a la sesión A y pregúntate: ¿la descripción contiene las palabras que acabo de escribir?

**Si se disparó pero hizo algo distinto:** el problema sí está en el cuerpo. Corrígelo ahí.

---

## Trabajo en pareja

Uno construye y comparte pantalla. El otro lee la descripción en voz alta y pregunta:

> ¿Esa palabra la escribirías tú de verdad?

**A los 10 minutos, cambian.**

---

## Entrega
Pega en el chat **solo la línea `description:`** de tu skill.

## Terminado cuando
La skill se dispara sola en una sesión nueva, con una petición en lenguaje natural.

## Si algo falla

| Problema | Causa más probable |
|---|---|
| No se dispara sola | La descripción no tiene las palabras que usaste al pedirlo |
| Se dispara pero hace algo distinto | Éxito parcial: la activación funciona. El cuerpo se afina después |
| Claude generó algo enorme | Pídele que lo recorte. Menos es más |
| No encuentro mi skill | Revisa que esté en `~/.claude/skills/<nombre>/SKILL.md` |

## Reto opcional
Agrega contexto dinámico con `` !`comando` `` y comprueba que la instrucción llega con los datos ya adentro.

## Para llevarte
Si la skill no se dispara sola, el problema casi nunca está en el cuerpo. Está en la descripción.
