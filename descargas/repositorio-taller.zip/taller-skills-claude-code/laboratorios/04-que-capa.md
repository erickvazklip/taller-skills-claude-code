# Laboratorio 4 · Qué capa usar
**6 minutos · salas de 3 a 4 · sin teclado**

## Qué vas a lograr
Criterio para no meter todo en el mismo lugar.

## Tu caso
Tu sala tiene **un caso asignado**. Decidan entre estas cinco capas:

| Capa | Para qué |
|---|---|
| `CLAUDE.md` | Hecho permanente, siempre en contexto |
| **Skill** | Procedimiento o referencia, cuesta contexto solo al usarse |
| Subagente | Tarea con contexto aislado y rol propio |
| Hook | Regla que debe cumplirse siempre, sin criterio del modelo |
| Servidor MCP | Acceso a un sistema externo |

## Las dos preguntas que desempatan

- **CLAUDE.md o skill** → ¿hace falta en *cada* conversación, o solo en *algunas*?
- **Skill o hook** → ¿confío en que el modelo *decida* aplicarlo?

## Preparen 60 segundos de defensa

Respondan dos cosas:

1. Por qué esa capa
2. Qué capa descartaron y por qué

**Nombren a quien va a hablar antes de que se acabe el tiempo.**

## Los casos

**A.** *"Mi equipo siempre olvida correr el linter antes de commitear. Ya lo puse en el CLAUDE.md y lo siguen olvidando."*

**B.** *"Cada vez que analizo un query tengo que pegarle el esquema de la base."*

**C.** *"Quiero un análisis completo de dependencias, pero llena mi contexto de basura y luego no puedo seguir trabajando."*

**D.** *"Los mensajes de commit de mi equipo son un desastre. Quiero un formato consistente."*

**E.** *"Mi proyecto usa un framework interno que Claude no conoce y se lo tengo que explicar cada vez."*

> Dos de estos casos **no tienen respuesta única**. Si su sala no llega a acuerdo, presenten el desacuerdo: eso es el ejercicio.

## Para llevarte
La pregunta no es qué herramienta usar. Es si esto hace falta siempre, a veces, o sin excepción.
