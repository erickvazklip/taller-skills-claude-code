# Laboratorio 3 · Partir la skill
**12 minutos · en pareja**

## Qué vas a lograr
La misma skill, repartida en tres archivos, con el grado de libertad decidido a conciencia.

## Estructura objetivo

```
tu-skill/
├── SKILL.md          ← queda solo el procedimiento
├── reference.md      ← el detalle que casi nunca hace falta
└── scripts/
    └── revisar.sh    ← lo que se ejecuta
```

## Pasos

**1.** Saca del `SKILL.md` todo lo que sea detalle de consulta y ponlo en `reference.md`. Deja arriba solo el procedimiento.

**2.** En el `SKILL.md`, apunta al archivo de referencia:

```markdown
Para los casos especiales, consulta ${CLAUDE_SKILL_DIR}/reference.md
```

**3.** Si tu skill hace alguna verificación mecánica, muévela a un script:

```markdown
Ejecuta la verificación:

    bash ${CLAUDE_SKILL_DIR}/scripts/revisar.sh
```

**4.** Decide el grado de libertad y anótalo como comentario al final del `SKILL.md`:

```markdown
<!-- Grado de libertad: ALTA / MEDIA / BAJA -->
```

**5.** Prueba que sigue funcionando.

## Las tres reglas que se verifican

- [ ] **Un solo nivel.** `SKILL.md` → `reference.md`. `reference.md` **no** apunta a un tercer archivo.
- [ ] **Rutas con `${CLAUDE_SKILL_DIR}`.** Nunca absolutas, nunca con barra invertida.
- [ ] **El script se ejecuta.** No le pides a Claude que lo lea e interprete.

## Cómo elegir el grado de libertad

| Pregúntate | Si la respuesta es | Grado |
|---|---|---|
| ¿Varios caminos llegan al mismo buen resultado? | Sí | **Alta** — dirección general, en prosa |
| ¿Hay una forma preferida pero la variación es aceptable? | Sí | **Media** — plantilla o script con parámetros |
| ¿Se puede romper algo si se hace distinto? | Sí | **Baja** — comando exacto, prohibido variarlo |

## Entrega
Pega en el chat: `mi-skill — grado: alta / media / baja — porque ___` (máximo 15 palabras).

## Terminado cuando
La skill sigue funcionando después de partirla, y el script se ejecuta sin que salte la solicitud de permiso.

## Si algo falla

| Problema | Solución |
|---|---|
| Salta la solicitud de permiso al ejecutar el script | Falta declarar la herramienta en `allowed-tools` |
| Claude no encuentra el archivo de referencia | Ruta absoluta o barra invertida. Usa `${CLAUDE_SKILL_DIR}` |
| Funciona a veces sí y a veces no | Tienes una cadena de referencias. Apláñala a un nivel |

## Para llevarte
La pregunta no es cuánto detalle poner. Es qué tan frágil es la tarea.
