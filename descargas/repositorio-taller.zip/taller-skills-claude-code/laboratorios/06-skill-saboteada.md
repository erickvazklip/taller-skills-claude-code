# Laboratorio 6 · La skill saboteada
**9 minutos · en pareja**

## Qué vas a lograr
Diagnosticar bajo presión de tiempo, que es como se diagnostica en la vida real.

## Obtén la skill rota

```bash
git fetch && git checkout sabotaje
```

## El reto

Esta skill tiene **tres fallas**. Está diseñada para no activarse nunca.

Encuéntrenlas y déjenla funcionando.

**Pista:** una falla está en el frontmatter, una en la descripción y una en las rutas.

## Herramientas de diagnóstico

| Comando | Qué te dice |
|---|---|
| `/skills` | Si cargó, y con qué metadatos |
| `/doctor` | Si hay problemas de instalación |
| `/context` | Qué está ocupando la ventana |
| `claude --debug` | Qué pasa por dentro al resolver la solicitud |

## Cómo abordarlo

1. **Primero mira si carga.** `/skills` te dice si la ve. Si la ve pero sin descripción, ya sabes dónde está una falla.
2. **Luego intenta invocarla con `/`.** Si responde así pero no sola, el problema está en los metadatos o en la descripción.
3. **Al final revisa las rutas.** Pídele que siga las referencias y observa dónde se pierde.

## Entrega
Pega en el chat:

```
falla 1: ___ / falla 2: ___ / falla 3: ___
```

Tres o cuatro palabras cada una.

## Terminado cuando
La skill se dispara sola con una petición en lenguaje natural.

## Advertencia honesta
La mayoría encuentra dos de tres en nueve minutos. **Eso es lo esperado.** La tercera es difícil a propósito: es la que parece que está bien.

## Para llevarte
Las fallas de sintaxis las encuentra el validador. Las descripciones malas solo las encuentra el uso.
