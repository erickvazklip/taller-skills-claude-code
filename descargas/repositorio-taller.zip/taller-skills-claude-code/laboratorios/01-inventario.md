# Laboratorio 1 · Inventario de skills
**8 minutos · individual**

## Qué vas a lograr
Ver, en tu propia máquina, qué skills ya existen y de dónde viene cada una.

## Pasos

**1.** Abre Claude Code y escribe:

```
/skills
```

Mira la lista completa. Puede estar casi vacía: es normal.

**2.** Ahora pregúntale en lenguaje natural:

```
¿qué skills tienes disponibles y de dónde viene cada una?
```

**3.** Identifica **una** skill que no sabías que existía.

**4.** Pega en el chat una sola línea con este formato:

```
nombre-de-la-skill — nivel (personal / proyecto / plugin / empaquetada)
```

## Terminado cuando
Pegaste tu línea con nombre y nivel.

## Si algo falla

| Problema | Qué haces |
|---|---|
| `/skills` no devuelve nada | Tu versión puede ser antigua. Usa la pregunta en lenguaje natural, funciona igual |
| No tienes ninguna skill | Normal. Identifica una de las empaquetadas |
| No sabes qué nivel es | Pregúntale a Claude directamente de dónde la cargó |

## Para llevarte
La descripción de cada skill que acabas de ver está en el contexto de Claude **ahora mismo**. El cuerpo, no.
