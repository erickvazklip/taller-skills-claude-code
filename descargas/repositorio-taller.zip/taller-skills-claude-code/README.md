# Taller: Skills con Claude Code

**3 horas · remoto en vivo · 30 de septiembre, 9:00 a 12:00 h CDMX**
Impartido por Erick Vázquez Granados · OmniSys

---

## Empieza aquí

**Si vas a asistir al taller:**

1. Lee **[PREPARACION.md](PREPARACION.md)** y haz los siete pasos. Te toma 15 minutos.
2. Llega con una respuesta a: *¿qué le pido a Claude cada semana, escribiendo más o menos lo mismo?*

**Si ya tomaste el taller:**

- **[CUADERNILLO.md](CUADERNILLO.md)** es tu referencia. Está ordenado por lo que vas a necesitar consultar, no por el orden en que se enseñó.

**Si vas a impartirlo:**


---

## Qué hay aquí

```
.
├── PREPARACION.md          Antes del taller · 15 min
├── CUADERNILLO.md          Referencia rápida · para después
│
├── laboratorios/           Los seis, en versión para el participante
│   ├── 01-inventario.md
│   ├── 02-primera-skill.md      ← el central
│   ├── 03-partir-skill.md
│   ├── 04-que-capa.md
│   ├── 05-publicar-clonar.md
│   └── 06-skill-saboteada.md
│
├── skills/                 Cuatro skills funcionando, para leer y copiar
│   ├── resumiendo-cambios/      grado de libertad ALTA · mínima
│   ├── redactando-commits/      grado MEDIA · mínima
│   ├── revisando-readme/        grado MEDIA · multiarchivo con script
│   └── migrando-datos/          grado BAJA · con disable-model-invocation
│
├── plantillas/             Punto de partida para las tuyas
│   ├── 01-minima/
│   ├── 02-multiarchivo/
│   └── 03-baja-libertad/
│
├── sabotaje/               El laboratorio 6 (la solución no se abre antes)
├── sandbox/                Proyecto de práctica si no puedes usar el tuyo
└── publicaciones/          Donde publicas la tuya · lee CONTRIBUTING.md
```

---

## Las cuatro skills de ejemplo

Están ordenadas por complejidad creciente. Léelas en este orden:

| Skill | Qué te enseña |
|---|---|
| `resumiendo-cambios` | La estructura mínima y el contexto dinámico con `!` |
| `redactando-commits` | Cómo se escribe una descripción que se dispara bien |
| `revisando-readme` | Revelación progresiva: `reference.md` y `scripts/` |
| `migrando-datos` | Baja libertad y `disable-model-invocation` para acciones peligrosas |

Puedes copiarlas a tu máquina y usarlas hoy:

```bash
cp -r skills/resumiendo-cambios ~/.claude/skills/
```

---

## Después del taller

**Esta semana:**

1. Usa tu skill al menos **3 veces**
2. Anota dónde tropieza (una línea basta)
3. Corrige **una** cosa con el ciclo Claude A / Claude B

**A los 30 días** hay un check-in. Una skill que no se usa no se puede mejorar, y una skill escrita en un taller y nunca usada es igual a no haber venido.

---

## Kit de lectura posterior

Lo que no cupo en tres horas, con enlaces a la documentación oficial:

- Referencia completa del frontmatter
- Argumentos: `$ARGUMENTS`, `$1`, argumentos con nombre
- Skills empaquetadas de Claude Code
- Distribución por plugin y configuración administrada
- Conflictos de prioridad entre niveles
- Presupuesto de caracteres del listado de skills
- Evaluación sistemática con `skill-creator`
- Patrón planificar–validar–ejecutar
- Nombres calificados de herramientas MCP
- Portabilidad al estándar abierto Agent Skills

---

## Documentación oficial

- [Mejores prácticas para la creación de Skills](https://platform.claude.com/docs/es/agents-and-tools/agent-skills/best-practices)
- [Extend Claude with skills](https://code.claude.com/docs/en/skills)
- [Agent Skills overview](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview)
- [agentskills.io](https://agentskills.io) — estándar abierto
