# Cómo publicar tu skill

## Estructura

Crea una carpeta con **tu usuario de git** y adentro tu skill:

```
publicaciones/
└── tu-usuario/
    └── nombre-de-tu-skill/
        ├── SKILL.md
        ├── reference.md      (si aplica)
        └── scripts/          (si aplica)
```

Una carpeta por persona evita conflictos de merge.

## Publicar

```bash
mkdir -p publicaciones/tu-usuario
cp -r ~/.claude/skills/tu-skill publicaciones/tu-usuario/
git add publicaciones/tu-usuario
git commit -m "add: tu-skill"
git push
```

## Antes de publicar

- [ ] El `SKILL.md` no tiene rutas absolutas de tu máquina
- [ ] No hay credenciales, tokens ni datos de tu empresa
- [ ] El `allowed-tools` pide solo lo que la skill necesita de verdad
- [ ] La descripción se entiende sin que tú la expliques

## Probar la de alguien más

```bash
git pull
cp -r publicaciones/otra-persona/su-skill ~/.claude/skills/
```

**Antes de ejecutarla, lee su `allowed-tools`.** Una skill puede preaprobarse acceso amplio a herramientas. Si no entiendes por qué necesita lo que pide, pregúntale a quien la escribió antes de correrla.
