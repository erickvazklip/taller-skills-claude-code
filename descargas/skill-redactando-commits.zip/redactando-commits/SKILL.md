---
name: redactando-commits
description: Redacta el mensaje de commit a partir de los cambios
  preparados, siguiendo commits convencionales. Úsala cuando el usuario
  pida un commit, un mensaje de commit, o pregunte cómo describir su
  cambio.
allowed-tools: Read
---

## Cambios preparados

!`git diff --staged`

## Instrucciones

Redacta un mensaje de commit con esta estructura:

    <tipo>(<alcance>): <resumen en imperativo, minúscula, sin punto>

    <cuerpo opcional: por qué, no qué>

Tipos válidos: `feat`, `fix`, `refactor`, `docs`, `test`, `chore`, `perf`.

Reglas:

- El resumen va en imperativo: "agrega", no "agregado" ni "agregando"
- Máximo 72 caracteres en la primera línea
- El cuerpo explica **por qué** se hizo el cambio. El qué ya está en el diff
- Si los cambios preparados mezclan varios propósitos, dilo y sugiere
  cómo separarlos en commits distintos

Si no hay nada preparado, dilo y detente. No inventes un mensaje.

<!-- Grado de libertad: MEDIA. Formato preferido, con variación aceptable. -->
