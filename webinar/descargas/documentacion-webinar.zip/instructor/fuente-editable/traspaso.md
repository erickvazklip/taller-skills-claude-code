# Carpeta de traspaso

Webinar *Skills con Claude Code* · 1 de octubre · 9:00 · 90 minutos

Este documento es lo primero que lee quien va a llevar la parte práctica.
Todo lo demás del paquete se entiende después de esta página.

---

## Qué es esto y qué se te pide

El webinar tiene dos personas frente al micrófono:

| Rol | Quién | Qué hace |
|---|---|---|
| **Expositor** | Erick Vázquez | Abre, cierra, y los cinco bloques conceptuales entre demostraciones |
| **Demostrador** | Tú | Las seis demostraciones en pantalla compartida, con código corriendo en vivo |

**Son 52 de los 90 minutos.** No es un papel de apoyo: la parte práctica es
la mayor parte del webinar y es la que la audiencia recuerda.

Lo que se te pide, concretamente:

1. Correr seis demostraciones en tu máquina, con pantalla compartida, en el
   orden y los tiempos del **Guion de demostraciones**.
2. Narrar mientras corren. El guion trae el texto hablado; puedes decirlo
   tal cual o con tus palabras, pero las frases marcadas como **frase de
   cierre** se dicen completas.
3. Responder las preguntas técnicas del chat que te pase el moderador.
4. Un ensayo conjunto con Erick, y una corrida propia de las seis demos
   antes de ese ensayo.

Lo que **no** se te pide: preparar contenido, escribir material, diseñar
láminas ni improvisar. Todo está escrito.

---

## Lo que recibes

| Documento | Para qué | Cuándo lo lees |
|---|---|---|
| **Esta carpeta de traspaso** | Entender el reparto y el calendario | Primero, hoy |
| **Guía del demostrador** | Los conceptos que necesitas dominar para narrar y para que no te agarren en curva | Segundo, completa, antes del ensayo |
| **Guion de demostraciones** | Las seis demos paso a paso, con texto hablado y qué hacer si falla cada una | Tercero, y lo tienes abierto durante la transmisión |
| **Playbook del webinar** | El minuto a minuto y las señales de entrega entre Erick y tú | Lo lees una vez; en vivo lo tiene Erick |
| **Tarjeta de cabina** | Una página, impresa, junto al teclado | En vivo |
| **Banco de preguntas** | Respuestas preparadas, con quién contesta cada tipo | Lo tienes abierto en vivo |
| **`ambiente-demo/`** | Tres scripts que arman, verifican y resetean el ambiente | Lo corres el T-3 y el T-0 |
| **`respaldos/`** | Corridas ya capturadas, por si algo falla en vivo | Seis pestañas abiertas en vivo |

---

## Requisitos de tu máquina

Esto se verifica solo, con un script. Pero es lo que necesitas tener antes:

- **Claude Code** v2.1.233 o más nueva. La versión importa: por debajo de
  esa, el comando `claude plugin validate` de la demo 6 no existe.
- **git** y **python3** disponibles en la terminal.
- Sesión de Claude Code autenticada y funcionando.
- Permiso de escritura en `~/.claude/skills/`.
- Terminal que puedas poner a **18 puntos o más** con tema claro.

Para verificarlo:

```
bash ambiente-demo/preparar.sh
bash ambiente-demo/verificar.sh
```

`verificar.sh` te dice exactamente qué falta. Si algo falla, avísale a Erick
**el mismo día**, no la víspera.

> **La restricción que decide todo:** las demos corren en tu máquina, con tu
> sesión. Si tu ambiente no está listo, no hay parte práctica. Es la única
> dependencia del webinar que no tiene sustituto.

---

## Las señales de entrega en vivo

Es la parte del traspaso que más se descuida y la que más se nota cuando
falta. Cada cambio de voz tiene una señal acordada, y son solo cuatro.

### Erick te entrega la pantalla

Erick cierra su bloque con una frase de puente. La última es siempre una
pregunta o una invitación, y es tu señal:

> *"...y eso se ve mejor corriéndolo. Adelante."*

Tú respondes con la primera línea del guion de esa demo. **No agradezcas, no
digas "gracias Erick", no te presentes otra vez.** Cada vez que alguien
agradece un cambio de turno, el webinar pierde ocho segundos y algo de
ritmo.

### Tú le devuelves la pantalla

Cierras con la **frase de cierre** de la demo, que está al final de cada
sección del guion y en la tarjeta de cabina. Esa frase es la señal. Después
de decirla, **te callas**. No agregues *"y con eso te lo dejo"*.

Ejemplo, final de la demo 1:

> *"Todo eso estaba escrito en un archivo, una sola vez."*

Erick arranca desde ahí.

### Te quedas sin saber qué sigue

Di exactamente esto:

> *"Erick, ¿le seguimos con el mecanismo?"*

Es una frase neutral que suena planeada y le devuelve el control. Sirve si
te perdiste, si algo falló, o si ya no sabes cuánto tiempo llevas.

### Erick necesita recuperar el tiempo

Si vas largo, Erick va a decir:

> *"Antes de que sigas con eso, una cosa rápida."*

Eso significa **corta donde estés y devuelve la pantalla**. No es una
interrupción y no discutes: significa que el reloj se salió de control y él
lo está corrigiendo. El guion trae, en cada demo, qué recortar.

---

## Las dos formas de operar

Hay dos modelos y hay que escoger uno **en el ensayo**, no en vivo.

### Modelo A · narras tú · el recomendado

Tú manejas teclado y voz durante las demos. Erick no interviene salvo para
recuperar tiempo.

**A favor:** una sola voz por bloque, sin cruces de audio. Es lo que el
guion supone por defecto.

**En contra:** narrar y teclear al mismo tiempo es más difícil de lo que
parece. Requiere el ensayo completo.

### Modelo B · narra Erick · tú manejas el teclado

Erick habla durante toda la demo y tú ejecutas los comandos siguiendo el
guion, sin hablar salvo para reportar resultados.

**A favor:** más fácil si no tienes experiencia en transmisión, y libera tu
atención para la terminal.

**En contra:** requiere que los dos se conozcan el guion al mismo nivel, y
que acuerden una señal de "ya escribí, ya puedes seguir" — en el ensayo se
acuerda cuál. Si Erick narra sobre un comando que todavía no corriste, se
nota de inmediato.

> **Si es tu primera transmisión en vivo, escoge el modelo B para las demos
> 3 y 4** — las dos de riesgo alto — y el modelo A para las otras cuatro.
> Es una combinación válida y funciona mejor que forzar un solo modelo.

---

## Calendario conjunto

### T-7 días · Lectura y primer contacto

**Tú:**
- [ ] Lees esta carpeta completa
- [ ] Lees la **Guía del demostrador** completa. No la hojees: en vivo te
      van a preguntar cosas que están ahí
- [ ] Corres `preparar.sh` y `verificar.sh` en tu máquina
- [ ] Le confirmas a Erick que tu ambiente pasa, o qué falta

**Erick:**
- [ ] Te entrega el paquete completo
- [ ] Te confirma modelo A o B como punto de partida

### T-3 días · Tu corrida en solitario

**Tú, solo, con cronómetro:**
- [ ] Las seis demos de principio a fin
- [ ] Las demos 3 y 4, **tres veces cada una**. Son las que dependen de que
      el modelo responda algo concreto
- [ ] Anotas en el margen del guion qué respondió el modelo cada vez

> **La decisión que sale de aquí:** si en tres corridas la descripción mala
> de la demo 3 se disparó dos o más veces, el A/B en vivo no es confiable.
> Cámbiate a la **variante narrada** del respaldo `R3-descripcion.md` y
> dilo en el ensayo. No es un plan B: es la opción correcta cuando el azar
> no acompaña.

### T-2 días · Ensayo conjunto

**90 minutos, los dos, con la transmisión real.** No es una lectura del
guion: es el webinar completo, cronometrado, con las señales de entrega.

Lo que se prueba, en este orden:
- [ ] Las cuatro señales de entrega, una por una, en seco, antes de empezar
- [ ] Las seis demos con sus tiempos
- [ ] Un fallo provocado: Erick escoge una demo al azar y te dice *"se
      cayó"*. Tienes que pasar al respaldo en menos de 30 segundos
- [ ] El punto de control: ¿a las 0:47 empezó la demo 4?

**Criterio de aceptación.** El ensayo pasa si se cumplen las cuatro:

1. La demo 4 arranca antes del minuto 50.
2. Las seis frases de cierre se dijeron completas.
3. Pasaste a un respaldo en menos de 30 segundos cuando se te pidió.
4. Nadie agradeció un cambio de turno.

Si falla cualquiera, hay ensayo de repaso el T-1, de 30 minutos, solo de lo
que falló.

### T-1 día · Cabina

**Tú:**
- [ ] `resetear.sh` y `verificar.sh`
- [ ] Los seis respaldos abiertos en pestañas del navegador, **no** en el
      explorador de archivos
- [ ] Tarjeta de cabina impresa, junto al teclado
- [ ] Guion en la segunda pantalla
- [ ] Banco de preguntas abierto

### T-1 hora

- [ ] `resetear.sh` y `verificar.sh` otra vez. **Siempre otra vez**
- [ ] Terminal a 18 pt o más, tema claro, ventana al 70% del ancho
- [ ] Notificaciones silenciadas: correo, mensajería, calendario
- [ ] Modo No molestar del sistema
- [ ] Audio probado con Erick
- [ ] Agua a la mano

> **El error más común de webinar:** una notificación emergente sobre la
> pantalla compartida. Revísalo dos veces, porque la primera no cuenta.

---

## Qué decides tú y qué decide Erick

Esto evita la conversación incómoda a media transmisión.

| Decisión | Quién |
|---|---|
| Si una demo se corta y pasa a respaldo | **Tú**, sin pedir permiso |
| Si la demo 3 va en vivo o narrada | **Tú**, con base en tu corrida del T-3 |
| Modelo A o B en cada demo | Los dos, en el ensayo |
| Si se recorta contenido por tiempo | **Erick** |
| El orden de los bloques | **Erick** |
| Qué preguntas técnicas se responden en vivo | **Tú** |
| Qué preguntas se dejan para el correo | **Erick** |
| Si se extiende más allá de los 90 minutos | **Erick** |

> La regla que resuelve el 90% de las dudas en vivo: **lo que pasa dentro
> de tu pantalla lo decides tú; lo que pasa con el reloj y con el orden lo
> decide Erick.**

---

## Las cinco reglas de demostrar en transmisión

Están también en el guion, pero si solo memorizas cinco cosas de todo el
paquete, que sean estas.

**1 · Narra antes de escribir, no después.** Di qué vas a hacer, luego
hazlo. Si escribes primero y explicas después, la audiencia pasa el comando
entero leyendo en vez de escuchando.

**2 · Escribe despacio y en voz alta.** En transmisión hay de uno a tres
segundos de retraso de video. Lo que a ti te parece ritmo normal, del otro
lado se ve como un salto.

**3 · Cuando algo funcione, para dos segundos.** El silencio marca el
momento. Si sigues hablando encima del resultado, nadie registra que acaba
de pasar algo.

**4 · Anuncia los tiempos muertos.** Mientras Claude responde hay de cinco a
veinte segundos de nada. Llénalos con contexto, nunca con silencio: en
transmisión el silencio se lee como falla técnica.

**5 · Si una demo falla, córtala a los 45 segundos.** No hay premio por
arreglarla en vivo y el costo de intentarlo es perder a la mitad de la
audiencia. Pasa al respaldo y sigue.

---

## Lo único que no puede pasar

Tres cosas hunden una parte práctica, y ninguna tiene que ver con que una
demo falle.

**Pedir disculpas más de una vez.** La audiencia acepta un fallo técnico sin
problema. Lo que no perdona es a alguien disculpándose cada cinco minutos:
a partir de la segunda disculpa, deja de escuchar el contenido y empieza a
vigilar el siguiente error.

**Intentar arreglar algo en vivo más de 45 segundos.** Cada segundo después
del 45 cuesta audiencia y no recupera nada. Los respaldos existen para eso.

**Fingir que una corrida capturada es en vivo.** Di "esto es lo que respondió
ayer" en pasado. Se nota, y cuando se nota pierdes lo único que no se
recupera en 90 minutos, que es la credibilidad.
