# Tarjeta de cabina

## Antes de abrir el micrófono

```
bash ambiente-demo/resetear.sh
bash ambiente-demo/verificar.sh
```

- Terminal 18 pt · tema claro · 70% del ancho
- No molestar activado · correo y mensajería cerrados
- Seis respaldos en pestañas
- Guion en la segunda pantalla

## Las seis demos

| Min | Demo | Primer comando |
|---|---|---|
| 0:02 | 1 · Tres minutos | `git diff HEAD` |
| 0:15 | 2 · Anatomía | `cat ~/.claude/skills/revisando-cambios/SKILL.md` |
| 0:27 | 3 · Descripción A/B | `mkdir -p ~/.claude/skills/ayudante-docs` |
| **0:47** | **4 · Destilador** | `claude` |
| 1:05 | 5 · Multiarchivo | `find ~/.claude/skills/revisando-readme` |
| 1:12 | 6 · Diagnóstico | `cat ~/.claude/skills/doc-helper/SKILL.md` |

**0:47 es el único reloj.** Si la demo 4 no arrancó, ya vas tarde.

## Frases de cierre · se dicen completas

1. Todo eso estaba escrito en un archivo, una sola vez.
2. La descripción siempre está en contexto. El cuerpo, no.
3. Si no se dispara, el problema está en la descripción.
4. Nadie escribe un SKILL.md bueno de memoria y a la primera.
5. Los scripts se ejecutan, no se leen.
6. Las descripciones malas no las marca ninguna herramienta.

## Prompt destilador · demo 4

```
Destila esta conversación en un SKILL.md de
Claude Code.

Nombre en gerundio. Descripción en tercera
persona con la fórmula [qué hace] + "Úsala
cuando..." usando las palabras que yo usé de
verdad en esta conversación, no lenguaje de
manual. En el cuerpo pon solo el contexto que
tuve que darte y que no sabías; quita todo lo
que ya sabías. Menos de 60 líneas. Termina con
un comentario del grado de libertad.

Dame el archivo y el mkdir. Nada más.
```

## Prompt de la demo 4, paso 1

```
mira el diff de este repo y redáctame el
mensaje de commit. Usamos commits
convencionales: tipo entre paréntesis el
alcance, resumen en imperativo y menos de 72
caracteres. El cuerpo explica por qué, no qué.
```

## Tres frases de emergencia

**Me perdí:**

> Erick, ¿le seguimos con el mecanismo?

**Algo falló y paso a respaldo:**

> Esto lo corrí ayer y lo tengo capturado.
> Lo leemos, que para este punto sirve igual.

**No sé la respuesta:**

> No lo sé de memoria y prefiero no
> inventarlo. Lo anoto y va en el correo de
> seguimiento.

## Regla de los 45 segundos

Si una demo no responde, **45 segundos y corta**. Abres el respaldo y sigues.
Una disculpa, no dos.

## Qué respaldo abre cada demo

| Demo | Respaldo |
|---|---|
| 1 | `R1-apertura.md` |
| 2 | no necesita |
| 3 | `R3-descripcion.md` |
| 4 | `R4-destilador.md` |
| 5 | `R5-multiarchivo.md` |
| 6 | `R6-diagnostico.md` |
| todo | `R0-sin-ambiente.md` |

## Diagnóstico

| Comando | Para |
|---|---|
| `/skills` | qué cargó y de dónde |
| `/doctor` | instalación y frontmatter |
| `/context` | qué ocupa la ventana |
| `claude --debug` | errores de parseo |

## Las tres que no debes decir mal

- El comando sale del **nombre del directorio**, no del campo `name`
- El tope es **1,536** caracteres, no 1,024
- El cuerpo **se queda** en contexto tras invocarla

## Señales de entrega

| Señal | Significa |
|---|---|
| Erick termina en **"Adelante"** | Tomas la pantalla |
| Dices la **frase de cierre** | La devuelves, y te callas |
| **"Erick, ¿le seguimos con el mecanismo?"** | Me perdí, toma el control |
| Erick: **"antes de que sigas, una cosa rápida"** | Corta donde estés, van tarde |

La demo 5 **no** devuelve la pantalla: enlaza directo con la demo 6.

No agradezcas el cambio de turno.

## Lo que no puede pasar

- Disculparte más de una vez
- Pelear con una demo más de 45 segundos
- Fingir que una captura es en vivo
- Hablar encima de Erick
