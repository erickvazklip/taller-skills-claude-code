# Playbook del webinar

Skills con Claude Code · 90 minutos · transmisión en vivo

Este documento es el minuto a minuto y es del **expositor**. El detalle de
cada demostración está en el **Guion de demostraciones**, que es del
**demostrador**; aquí está el hilo que las une.

---

## Los dos roles

| Rol | Quién | Minutos | Qué tiene en la mano |
|---|---|---|---|
| **Expositor** | Erick | 38 | Este playbook |
| **Demostrador** | Segunda persona | 52 | Guion, tarjeta de cabina, respaldos |

El traspaso al demostrador, su preparación y el criterio de aceptación del
ensayo están en la **Carpeta de traspaso**. Este playbook supone que ese
traspaso ya ocurrió.

---

## Tabla de control

| Hora | Bloque | Min | Voz |
|---|---|---|---|
| 0:00 | Apertura | 2 | **Erick** |
| 0:02 | **DEMO 1** · La skill en tres minutos | 6 | Demostrador |
| 0:08 | Por qué existen las skills | 7 | **Erick** |
| 0:15 | **DEMO 2** · Anatomía de un SKILL.md | 7 | Demostrador |
| 0:22 | Dónde viven y quién gana | 5 | **Erick** |
| 0:27 | **DEMO 3** · La descripción, A/B | 10 | Demostrador |
| 0:37 | Las cuatro reglas | 5 | **Erick** |
| 0:42 | Preguntas del chat · tanda 1 | 5 | **Erick** reparte |
| 0:47 | **DEMO 4** · El destilador | 12 | Demostrador |
| 0:59 | Grados de libertad | 6 | **Erick** |
| 1:05 | **DEMO 5** · Multiarchivo y script | 7 | Demostrador |
| 1:12 | **DEMO 6** · La skill que no funciona | 8 | Demostrador |
| 1:20 | Cierre y el kit | 7 | **Erick** |
| 1:27 | Preguntas del chat · tanda 2 | 3 | **Erick** reparte |

**52 de los 90 minutos son pantalla compartida con código corriendo.**
Es la proporción que separa un webinar de una presentación. Y son 52 minutos
que no dependen de ti: **la preparación del demostrador es la ruta crítica
del webinar.**

### El punto de control único

> **Si a las 0:47 no ha empezado la demo 4, están retrasados.**

Es el único reloj que importa, y lo vigilas tú, no el demostrador. Todo
ajuste se hace recortando las demos 5 y 6, nunca la 4.

### Las cuatro señales de entrega

Acordadas con el demostrador en el ensayo. No se improvisan.

| Señal | Quién la dice | Qué significa |
|---|---|---|
| Frase de puente que termina en *"Adelante"* | Erick | Te entrego la pantalla |
| La frase de cierre de la demo | Demostrador | Te la devuelvo |
| *"Erick, ¿le seguimos con el mecanismo?"* | Demostrador | Me perdí, toma el control |
| *"Antes de que sigas con eso, una cosa rápida"* | Erick | Corta donde estés, vamos tarde |

> **La regla que evita la conversación incómoda en vivo:** lo que pasa dentro
> de la pantalla del demostrador lo decide él; el reloj y el orden los
> decides tú.

---

# Antes de transmitir

El calendario completo, con las dos columnas, está en la **Carpeta de
traspaso**. Aquí está solo lo tuyo.

## T-7 días · Traspaso

- [ ] Entregas el paquete completo al demostrador
- [ ] Le confirmas modelo A o B como punto de partida
- [ ] Recibes su confirmación de que su ambiente pasa la verificación

> **El riesgo número uno del webinar no es que una demo falle: es que el
> demostrador no haya corrido nada hasta la víspera.** Pide la confirmación
> del T-7 por escrito.

## T-3 días · Su corrida en solitario

Él corre las seis demos solo, cronometrando, y las demos 3 y 4 tres veces
cada una. De ahí sale una decisión que es suya: si la demo 3 va en vivo o
en la variante narrada.

Tú no tienes tarea este día, salvo estar disponible.

## T-2 días · Ensayo conjunto

**90 minutos, los dos, con la transmisión real.** No es una lectura: es el
webinar completo, cronometrado.

- [ ] Las cuatro señales de entrega, en seco, antes de empezar
- [ ] Las seis demos con sus tiempos
- [ ] Un fallo provocado: escoges una demo al azar y dices *"se cayó"*. Él
      tiene que pasar al respaldo en menos de 30 segundos
- [ ] El punto de control: ¿a las 0:47 empezó la demo 4?

**Criterio de aceptación.** El ensayo pasa si se cumplen las cuatro:

1. La demo 4 arranca antes del minuto 50.
2. Las seis frases de cierre se dijeron completas.
3. Pasó a un respaldo en menos de 30 segundos cuando se le pidió.
4. Nadie agradeció un cambio de turno.

Si falla cualquiera, hay ensayo de repaso el T-1, de 30 minutos, solo de lo
que falló. **No lo saltes por cortesía:** el ensayo de repaso es más barato
que un webinar descarrilado.

## T-1 día

**Tú:**
- [ ] Confirmas quién modera el chat y le pasas el Apéndice B
- [ ] Tus cinco bloques hablados leídos en voz alta una vez, con cronómetro
- [ ] Ligas del kit y de la grabación listas para pegar en el chat

**Él:** ambiente, respaldos en pestañas, tarjeta impresa.

## T-1 hora

- [ ] Audio probado entre los dos
- [ ] Grabación configurada y probada
- [ ] Notificaciones silenciadas en **las dos** máquinas
- [ ] Modo No molestar en las dos
- [ ] Acordado quién comparte pantalla primero y cómo se alterna
- [ ] Agua a la mano

> **El error más común de webinar:** una notificación emergente sobre la
> pantalla compartida. Con dos presentadores el riesgo se duplica: revisa que
> él también lo haya hecho, no lo supongas.

## T-5 minutos · Mensaje de sala de espera

```
Bienvenidos. Empezamos en 5 minutos.

Tres cosas mientras tanto:

1. Si tienes Claude Code instalado, ábrelo. Vas a poder seguir la
   primera demostración en paralelo.
2. Las preguntas van al chat en cualquier momento. Las respondemos
   en dos tandas y ninguna se pierde.
3. Esto se graba. La liga llega por correo, junto con el kit
   de material.
```

---

# El webinar, minuto a minuto

## 0:00 · Apertura

**2 minutos · hablado**

No abras con una diapositiva de agenda. En un webinar, los primeros noventa
segundos deciden cuánta gente sigue ahí en el minuto veinte.

> Buenos días. En los próximos noventa minutos van a ver cómo dejar de
> repetirle lo mismo a Claude cada semana.
>
> Estamos dos personas hoy: yo llevo el hilo y <nombre> lleva el teclado.
> La mayor parte de esto se ve en pantalla, corriendo.
>
> No voy a explicarles qué son las skills todavía. Primero se los voy a
> mostrar, con código real, y después vemos qué pasó. Adelante.

Esa última palabra es la señal de entrega. **Dila y cállate**, sin agregar
nada después.

**Lo que NO haces en la apertura:** presentar currículums —ni el tuyo ni el
del demostrador—, mostrar la agenda completa, explicar qué es Claude Code,
agradecer a los organizadores. Todo eso va al cierre o no va.

**La presentación del demostrador son doce palabras**, en la apertura, y no
se repite. Si le das un párrafo de introducción, gastas 40 segundos de los
primeros noventa, que son los que deciden cuánta gente sigue ahí en el
minuto veinte.

---

## 0:02 · DEMO 1 · La skill en tres minutos

**6 minutos · demostrador** → *Guion de demostraciones, demo 1*

Te devuelve con: *"Todo eso estaba escrito en un archivo, una sola vez."*

---

## 0:08 · Por qué existen las skills

**7 minutos · hablado**

### El problema, nombrado (2 min)

> Lo que acaban de ver resuelve un problema concreto: el conocimiento
> operativo vive en prompts que vuelven a escribir.
>
> Cada semana explican otra vez las convenciones del repo. Cada PR repiten
> qué revisar. Cada persona nueva pregunta lo mismo. Y cada sesión arranca
> desde cero.

### El mecanismo (3 min)

> Claude tiene una ventana de contexto finita. Todo lo que quieren que sepa
> compite por ese espacio: su código, su conversación, sus convenciones.
>
> Las skills parten el contenido en dos niveles. La descripción vive
> permanentemente en contexto: es corta, y dice que la skill existe y cuándo
> aplicarla. El cuerpo solo entra cuando se usa.

### Por qué no es lo mismo que CLAUDE.md (2 min)

> Alguien está pensando: "esto ya lo tengo en mi CLAUDE.md". La diferencia
> es el costo. Lo que está en CLAUDE.md se carga en **todas** sus
> conversaciones, la use o no. El cuerpo de una skill, no.
>
> La pregunta que decide entre uno y otro: ¿hace falta en cada conversación,
> o solo en algunas? Si es en algunas, es skill.

**Frase de cierre:**

> La descripción siempre está en contexto. El cuerpo, no. Ese es todo el
> truco.

---

## 0:15 · DEMO 2 · Anatomía de un SKILL.md

**7 minutos · demostrador** → *Guion de demostraciones, demo 2*

Te devuelve con: *"La descripción siempre está en contexto. El cuerpo, no."*

---

## 0:22 · Dónde viven y quién gana

**5 minutos · hablado**

Apoya con una lámina; es de los pocos momentos donde una tabla ayuda más
que la terminal.

| Ubicación | Ruta | Alcance |
|---|---|---|
| Empresarial | Configuración administrada | Toda la organización |
| Personal | `~/.claude/skills/` | Todos tus proyectos |
| Proyecto | `.claude/skills/` | Ese repositorio |
| Plugin | `<plugin>/skills/` | Donde esté activo |

> El nivel de proyecto es el que cambia la vida en equipo. Una skill ahí se
> versiona con el código: quien clona el repositorio hereda su criterio sin
> que se lo expliquen. No hay instalación, no hay que avisarle a nadie.

> En conflicto de nombres: empresarial gana sobre personal, personal sobre
> proyecto.

**Un detalle que corrige un error muy extendido:**

> El comando que escriben sale del **nombre del directorio**, no del campo
> `name`. En skills personales y de proyecto, `name` es solo la etiqueta
> del listado, y ni siquiera es obligatorio.

---

## 0:27 · DEMO 3 · La descripción, A/B

**10 minutos · demostrador** → *Guion de demostraciones, demo 3*

Te devuelve con: *"Si no se dispara, el problema está en la descripción."*

**Puede llegar en su variante narrada** si en su corrida del T-3 el A/B no
resultó confiable. Es su decisión y es la correcta: tú no la cuestionas en
vivo.

---

## 0:37 · Las cuatro reglas

**5 minutos · hablado**

Consolida lo que acaban de ver. Una lámina, cuatro puntos.

> **Uno · tercera persona.** "Analiza", nunca "Te puedo ayudar". La
> descripción se inyecta en la indicación del sistema.
>
> **Dos · qué hace más cuándo usarla.** Las dos mitades son obligatorias.
>
> **Tres · el caso principal al inicio.** El listado tiene tope de
> caracteres. Si se recorta, se recorta por el final.
>
> **Cuatro · las palabras que ustedes escriben.** No las del manual.

> Truco práctico, y es el que más sirve: escriban primero cómo pedirían la
> tarea, en voz alta, y de ahí saquen las palabras de la descripción.

**El tope real:** 1,536 caracteres, combinado entre `description` y
`when_to_use`.

---

## 0:42 · Preguntas del chat · tanda 1

**5 minutos**

El moderador te pasa las tres o cuatro más repetidas. Responde esas, no las
más interesantes.

> Las que no alcancemos ahora las retomo al final, y las que queden se
> responden por correo con el kit. Ninguna se pierde.

**Si nadie preguntó nada:** no lo señales. Usa una del banco de preguntas
como si te la hubieran hecho, y sigue. El silencio en el chat es normal en
los primeros cuarenta minutos.

**El reparto de esta tanda.** Las preguntas de mecánica —rutas, permisos,
frontmatter, por qué no se dispara— van al demostrador. Las de adopción,
equipo, gobierno y comparaciones con otras herramientas son tuyas. Dilo en
voz alta al repartir: *"esa es de mecánica, <nombre>"*. La audiencia
entiende el reparto de inmediato y deja de dirigir todo a una sola voz.

---

## 0:47 · DEMO 4 · El destilador

**12 minutos · demostrador** → *Guion de demostraciones, demo 4*

Te devuelve con: *"Nadie escribe un SKILL.md bueno de memoria y a la
primera."*

**Es la demo más importante del webinar.** Si vas retrasado, recorta de las
demos 5 y 6, nunca de esta.

---

## 0:59 · Grados de libertad

**6 minutos · hablado**

> Última pieza conceptual, y es la más transferible.
>
> Imaginen un robot que tiene que cruzar de un lado a otro. En campo abierto
> le dicen "ve al otro lado" y ya: cualquier ruta sirve. En un puente
> angosto con precipicios, le dan el paso exacto y le prohíben improvisar.
>
> Sus skills son iguales. La pregunta no es "¿cuánto detalle pongo?" sino
> "¿qué tan frágil es esta tarea?".

| Grado | Cuándo | Cómo se escribe |
|---|---|---|
| **Alta** | Varios caminos sirven | Prosa, dirección general |
| **Media** | Hay un patrón preferido | Plantilla o script con parámetros |
| **Baja** | Se puede romper algo | Comando exacto y prohibición de variarlo |

> En baja libertad la prohibición explícita es parte del diseño, no un
> adorno. Sin ella, un modelo capaz va a intentar arreglar el problema, que
> es exactamente lo que no quieren en una migración.

> El error típico: escribir todas sus skills con el mismo nivel de detalle.
> Las de alta quedan asfixiadas y las de baja, peligrosamente vagas.

---

## 1:05 · DEMO 5 · Multiarchivo y script

**7 minutos · demostrador** → *Guion de demostraciones, demo 5*

**No te devuelve la pantalla:** enlaza directo con la demo 6. No intervengas
entre las dos.

---

## 1:12 · DEMO 6 · La skill que no funciona

**8 minutos · demostrador** → *Guion de demostraciones, demo 6*

Te devuelve con: *"Las descripciones malas no las marca ninguna
herramienta."* Desde ahí cierras tú.

---

## 1:20 · Cierre y el kit

**7 minutos · hablado**

### Lo que se llevan (2 min)

Comparte la liga del kit en el chat **mientras** lo describes, no después.

```
El kit del asistente está aquí: [ENLACE]

Adentro:
· Manual de 16 páginas en PDF
· Tarjeta de referencia para imprimir
· 13 skills listas para usar
· El prompt destilador que vieron en la demo 4
· Guía de primeros 30 días
```

> Las trece skills están listas para copiar. Están en tres dominios: ciclo
> de desarrollo, gestión de proyectos y validación de calidad documental.
> Cópienlas, úsenlas, modifíquenlas.

### El compromiso (3 min)

Esta es la parte que decide si el webinar sirvió de algo.

> Les voy a pedir una sola cosa, y es concreta.
>
> Hoy, en los próximos veinte minutos, copien **una** skill del kit y úsenla
> una vez. No la escriban: cópienla. Está en el archivo que se llama
> "Empieza aquí".
>
> Y esta semana, construyan la suya con el destilador que vieron. Una. No
> cinco.

> La razón por la que insisto en una: quien sale de un webinar y escribe
> cinco skills el mismo día, no usa ninguna. Quien copia una y la usa tres
> veces, en un mes tiene cuatro funcionando.

### El cierre (2 min)

> Empezamos con una demostración de tres minutos. Lo que vieron después fue
> el mecanismo detrás de esos tres minutos.
>
> La diferencia entre las dos cosas es un archivo de texto en una carpeta.

---

## 1:27 · Preguntas del chat · tanda 2

**3 minutos**

Mismo reparto que la tanda 1. Responde dos o tres y cierra con:

> Las que quedan las respondo por correo junto con la grabación y el kit.
> Gracias por los noventa minutos.

---

# Apéndice A · Si algo falla en transmisión

| Problema | Quién resuelve | Qué se hace |
|---|---|---|
| **Se cae el internet del demostrador** | **Tú** | Es el peor escenario. Tomas la voz y sigues con el respaldo `R0-sin-ambiente.md`, que tiene la estructura completa sin demos en vivo. Él se reconecta en paralelo |
| **Se cae tu internet** | Moderador | Anuncia pausa de 3 min. El demostrador **no** improvisa contenido conceptual: espera |
| **Una demo no responde** | Demostrador | 45 segundos máximo, luego respaldo. No le pidas que insista |
| **El modelo da una respuesta rara** | Demostrador | La lee igual y comenta qué esperaba. La audiencia aprende más de esto que de un acierto |
| **Él se equivoca al teclear** | Nadie | No lo señales desde tu micrófono. Corregir a alguien en vivo cuesta más que el error |
| **Se queda en blanco a media demo** | **Tú** | Espera su frase *"¿le seguimos con el mecanismo?"*. Si no la dice y pasan 15 segundos, entra tú con *"antes de que sigas con eso, una cosa rápida"* |
| **El chat se llena de una sola pregunta** | **Tú** | Respóndela de inmediato aunque no toque. Si veinte personas preguntan lo mismo, es contenido faltante |
| **Alguien trollea en el chat** | Moderador | Ninguno de los dos lo menciona |
| **Se va el tiempo** | **Tú** | Apéndice de recortes. Nunca la demo 4 ni el cierre |
| **Nadie interactúa** | Nadie | Normal. Que ninguno pregunte "¿se ve bien?" cada cinco minutos: proyecta inseguridad |

> **Lo único que no puede pasar:** que los dos hablen encima. Con dos
> presentadores, el cruce de audio es el fallo que más se nota y el que la
> audiencia menos perdona. Cuando dudes si es tu turno, **no hables**: el
> silencio de dos segundos no cuesta nada y el cruce sí.

---

# Apéndice B · Reparto de los tres

Con demostrador y moderador son tres personas. Acuerden esto **antes**, por
escrito:

| Momento | Moderador | Tú (expositor) | Demostrador |
|---|---|---|---|
| T-5 min | Publica el mensaje de sala de espera | Últimas ligas listas | Verifica ambiente, resetea |
| Apertura | — | Abres y lo presentas en 12 palabras | Espera con la terminal lista |
| Durante demos | Vigila que la pantalla se vea | **Vigilas el reloj** | Narra |
| Durante bloques | Filtra y agrupa el chat | Expones | **Resetea el ambiente para la demo siguiente** |
| 0:42 | Te pasa las 3-4 más repetidas | Repartes: técnicas a él, resto tú | Contesta las técnicas |
| 1:20 | Pega la liga del kit | Cierras | — |
| 1:27 | Te pasa 2-3 finales | Repartes y cierras | Contesta las técnicas |
| Después | Envía grabación y kit | Respondes pendientes por correo | Te pasa lo que anotó y no supo |

**Las dos reglas que sostienen el reparto:**

**Durante las demos, nadie lee el chat.** Ni el demostrador ni tú. Partir la
atención entre el chat y la terminal es la causa número uno de demos que se
descarrilan, y en tu caso te hace perder el hilo del reloj.

**Los bloques hablados son su ventana de reseteo.** Mientras tú expones, él
deja el ambiente listo para la demo que sigue. Por eso los bloques hablados
no se recortan a cero: si lo haces, llega sin ambiente a la demo siguiente.

---

# Apéndice C · Seguimiento

## T+1 día · Correo

```
Asunto: Tu kit de Skills con Claude Code

Gracias por los noventa minutos de ayer.

EL KIT: [ENLACE]

Adentro: el manual en PDF, la tarjeta de referencia para imprimir,
trece skills listas para copiar, el prompt destilador y la guía de
primeros 30 días.

LA GRABACIÓN: [ENLACE]

TU SIGUIENTE PASO, Y TOMA 20 MINUTOS:

Copia una skill del kit y úsala una vez hoy.
No la escribas: cópiala. Está en "Empieza aquí".

    cp -r kit-skills/desarrollo/redactando-commits ~/.claude/skills/

Y esta semana, construye la tuya con el destilador. Una, no cinco.

Las preguntas que quedaron en el chat, respondidas: [ENLACE o adjunto]

Erick
```

## T+7 días · Un solo recordatorio

```
Asunto: ¿Alcanzaste a probar una skill?

Una pregunta, respuesta de una línea:

¿Llegaste a usar alguna skill del kit? (sí / no / todavía no)

Si la respuesta es no, me sirve igual: me dice qué le faltó al webinar.

Si la respuesta es sí y quieres construir la tuya, el prompt destilador
está en el archivo 03 del kit.

Erick
```

**No mandes más de dos correos.** El tercero se marca como spam y arrastra
los dos anteriores.
